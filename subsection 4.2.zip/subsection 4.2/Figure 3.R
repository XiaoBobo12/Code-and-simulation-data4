setwd("D:/研究备份/研究5（针对随机延迟效应的免疫治疗的贝叶斯自适应设计）/绘图制表代码")
load("Scenario_1_to_9.RData")
load("Scenario2_1_to_9.RData")
results.pres<-data.frame(matrix(ncol=5,nrow=144))
varnames<-c("a.b","lambda","x.cat","Power","Design")
colnames(results.pres)<-varnames
for(i in 1:72)
{
  a=AD.simul.list[[i]]$Parameter.list$alpha
  b=AD.simul.list[[i]]$Parameter.list$beta
  results.pres$a.b[i]=paste("(list(a,b))==(list(",a,",",b,"))")
  results.pres$lambda[i]=paste("lambda==",AD.simul.list[[i]]$Parameter.list$lambda)
  d1=AD.simul.list[[i]]$Parameter.list$d1
  d20=AD.simul.list[[i]]$Parameter.list$d2
  n20=AD.simul.list[[i]]$Parameter.list$n2.min
  n2max=AD.simul.list[[i]]$Parameter.list$n2.max
  results.pres$x.cat[i]=paste(d1,d20,n20,n2max,sep="\n")
  results.pres$Power[i]=AD.simul.list[[i]]$Power.list$Power
  results.pres$Design[i]="Promising zone design"
}
for(i in 1:72)
{
  a=AD.simul.list[[i]]$Parameter.list$alpha
  b=AD.simul.list[[i]]$Parameter.list$beta
  results.pres$a.b[i+72]=paste("(list(a,b))==(list(",a,",",b,"))")
  results.pres$lambda[i+72]=paste("lambda==",AD.simul.list[[i]]$Parameter.list$lambda)
  d1=AD.simul.list[[i]]$Parameter.list$d1
  d20=AD.simul.list[[i]]$Parameter.list$d2
  n20=AD.simul.list[[i]]$Parameter.list$n2.min
  n2max=AD.simul.list[[i]]$Parameter.list$n2.max
  results.pres$x.cat[i+72]=paste(d1,d20,n20,n2max,sep="\n")
  results.pres$Power[i+72]=GSD.res.list[[i]]$Power.list$Power
  results.pres$Design[i+72]="Group sequential design"
}
results.pres$a.b=factor(results.pres$a.b)
results.pres$lambda=factor(results.pres$lambda)
results.pres$x.cat=factor(results.pres$x.cat)
results.pres$x.cat.num=rep(NA,144)
levels.x.cat=levels(results.pres$x.cat)
results.pres$Design=factor(results.pres$Design,levels=c("Promising zone design","Group sequential design"),labels=c("Promising zone design","Group sequential design"))
for(i in 1:8)
{
  results.pres$x.cat.num[results.pres$x.cat==levels.x.cat[i]]=i
}
library(ggplot2)
dev.set()
bitmap("D:/BoshengLi_Figure3.jpeg",type="jpeg",height =10.5 ,width = 18,res=800)
p<-ggplot(data=results.pres,mapping = aes(x=x.cat.num,y=Power,color=Design,shape=Design))+geom_line(linewidth=1)+geom_point(size=3)
p<-p+facet_grid(a.b~lambda,labeller = label_parsed,scales="free")+scale_x_continuous(breaks=seq(1,8,1),labels=levels.x.cat)+xlab((bquote((list(d[1],d[2]^0,n[2]^0,n[2]^max)))))+ylab("Empirical overall power")
p<-p+theme(axis.title = element_text(size=14),axis.text = element_text(size=12),legend.text = element_text(size=12),legend.title=element_text(size=14),strip.text = element_text(size=12))
p
dev.off()

