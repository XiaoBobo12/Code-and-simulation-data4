setwd("D:/研究备份/研究5（针对随机延迟效应的免疫治疗的贝叶斯自适应设计）/绘图制表代码")
load("Scenario_1_to_9.RData")
load("Scenario2_1_to_9.RData")
result.pres<-data.frame(matrix(ncol=9,nrow=72))
colnames(result.pres)<-c("a.b","lambda","d1","d2","RR.BA","n2","Avg.D","Avg.N","Power")
for(i in 1:72)
{
  result.pres$a.b[i]=paste("(",GSD.res.list[[i]]$Parameters.list$alpha,",",GSD.res.list[[i]]$Parameters.list$beta,")",sep="")
  result.pres$lambda[i]=GSD.res.list[[i]]$Parameters.list$lambda
  result.pres$d1[i]=GSD.res.list[[i]]$Parameters.list$d1
  result.pres$d2[i]=GSD.res.list[[i]]$Parameters.list$d2
  result.pres$RR.BA[i]=AD.simul.list[[i]]$Parameter.list$n2.min/A2
  result.pres$n2[i]=GSD.res.list[[i]]$Parameters.list$n2
  result.pres$Avg.D[i]=GSD.res.list[[i]]$Empirical.design.parameters$Average.events.number.simulation
  result.pres$Avg.N[i]=GSD.res.list[[i]]$Empirical.design.parameters$Average.patients.number.simulation
  result.pres$Power[i]=GSD.res.list[[i]]$Power.list$Power
}
write.csv(result.pres,file="Table 3.csv")