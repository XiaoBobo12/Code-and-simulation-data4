library(gsDesign)
library(mvtnorm)
## the survival function of the control group
surv.control<-function(t,rate0,k)
## t:the survival time
## rate0: the hazard parameter of the control group
## k:the shape parameter
{
  return(exp(-(rate0*t)^k))
}
## the hazard function of the control group
hazard.control<-function(t,rate0,k)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
{
  return(k*rate0^k*t^(k-1))
}
## the survival function of an individual in the immunotherapy group
## assuming a piece-wise Weibull distribution with the fixed delay time
surv.immuno.ind<-function(t,rate0,k,lambda,tstar)
## t:the survival time
## rate0: the hazard parameter of the control group
## k:the shape parameter
## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
## tstar: the delay time of an individual

{
  Surv<-(t<tstar)*exp(-(rate0*t)^k)+(t>=tstar)*exp((lambda-1)*(rate0*tstar)^k-lambda*(rate0*t)^k)
  return(Surv)
}

## the survival function of the overall immunotherapy group
surv.immuno<-function(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  if(tstar.min==tstar.max)
  {
    Surv<-surv.immuno.ind(t,rate0,k,lambda,tstar.min)
  }
  else
  {
    integrand<-function(tstar)
    {
      tstar.std=(tstar-tstar.min)/(tstar.max-tstar.min)
      value=surv.immuno.ind(t,rate0,k,lambda,tstar)*dbeta(tstar.std,shape1=alpha,shape2=beta)/(tstar.max-tstar.min)
      ##Note: after the scale transformation of the random variables, the deriviates between the new and old random variables need to be multiplied
      return(value)
    }
    after.onset<-integrate(integrand,lower=tstar.min,upper=t,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
    t.std=(t-tstar.min)/(tstar.max-tstar.min)
    before.onset<-pbeta(t.std,shape1=alpha,shape2=beta,lower.tail=FALSE)*surv.control(t,rate0,k)
    Surv<-after.onset+before.onset
  }
  return(Surv)
}

## the probability density function of the overall immunotherapy group
pdf.immuno<-function(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  if(tstar.min==tstar.max)
  {
    if(t<=tstar.min)
    {
      pdf<-hazard.control(t,rate0,k)*surv.control(t,rate0,k)
      
    }
    else
    {
      pdf<-lambda*hazard.control(t,rate0,k)*surv.immuno.ind(t,rate0,k,lambda,tstar.min)
    }
  }
  else
  {
    integrand<-function(tstar)
    {
      tstar.std=(tstar-tstar.min)/(tstar.max-tstar.min)
      value=lambda*hazard.control(t,rate0,k)*surv.immuno.ind(t,rate0,k,lambda,tstar)*dbeta(tstar.std,shape1=alpha,shape2=beta)/(tstar.max-tstar.min)
      ##Note: after the scale transformation of the random variables, the deriviates between the new and old random variables need to be multiplied
      return(value)
    }
    after.onset<-integrate(integrand,lower=tstar.min,upper=t,subdivisions=300,rel.tol = .Machine$double.eps, abs.tol= 1e-02,stop.on.error=FALSE)$value
    t.std=(t-tstar.min)/(tstar.max-tstar.min)
    before.onset<-pbeta(t.std,shape1=alpha,shape2=beta,lower.tail=FALSE)*surv.control(t,rate0,k)*hazard.control(t,rate0,k)
    pdf<-after.onset+before.onset
  }
  return(pdf)
}

##the hazard function of the overall immunotherapy group
hazard.immuno<-function(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  pdf<-pdf.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  surv<-surv.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  return(pdf/surv)
}

#####################################################################
############## Part 2:Distribution and death number #################
#####################################################################

## the following function is used to calculate the distribution of the log-rank test statistics at the each analysis without the sample size adjustment
Dist.para.fixed.design<-function(K,h.cens,A,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A:the duration of recruitment
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  pc=1/(1+K)
  pt=K/(1+K)
  Survival.censor.comb<-function(t)
  {
    Survival.adm<-punif(t,tau-A,tau,lower.tail = FALSE)
    Survival.rdm<-exp(-h.cens*t)
    return(Survival.adm*Survival.rdm)
  }
  pai<-function(t)
  {
    survival.control<-surv.control(t,rate0,k)
    survival.immunotherapy<-surv.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    pai=pc*survival.control/(pc*survival.control+pt*survival.immunotherapy)
    return(pai)
  }
  V.t<-function(t)
  {
    survival.control<-surv.control(t,rate0,k)
    hazard.control.value<-hazard.control(t,rate0,k)
    pdf.control<-hazard.control.value*survival.control
    pdf.immunotherapy<-pdf.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    Survival.censor<-Survival.censor.comb(t)
    V.t=(pc*pdf.control+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  mu.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.vec<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]<-pai(t[i])*(1-pai(t[i]))*(hazard.control.vec-hazard.immunotherapy.value)*V.t(t[i])/(pai(t[i])*hazard.control.vec+(1-pai(t[i]))*hazard.immunotherapy.value)
    }
    return(integrand)
  }
  mu=integrate(mu.integrand,lower=tstar.min,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
  sigma2.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])
    }
    return(integrand)
  }
  sigma2.tilde.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.value<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])*hazard.control.value*hazard.immunotherapy.value
      integrand[i]=integrand[i]/(pai(t[i])*hazard.control.value+(1-pai(t[i]))*hazard.immunotherapy.value)^2
    }
    return(integrand)
  }
  sigma2=integrate(sigma2.integrand,lower=0,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol= 1e-02,stop.on.error=FALSE)$value
  sigma2.tilde=integrate(sigma2.tilde.integrand,lower=0,upper=tau,subdivisions=300,rel.tol = .Machine$double.eps, abs.tol= 1e-02,stop.on.error=FALSE)$value
  return(list(mu=mu,sigma2=sigma2,sigma2.tilde=sigma2.tilde))
}

## the following function is used to calculate the distribution of the log-rank test statistics at the final analysis of the adaptive design
Dist.para.adaptive.design<-function(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n1: the sample size at the interim analysis
  ## n2: the sample size at the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  pc=1/(1+K)
  pt=K/(1+K)
  pai<-function(t)
  {
    survival.control<-surv.control(t,rate0,k)
    survival.immunotherapy<-surv.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    pai=pc*survival.control/(pc*survival.control+pt*survival.immunotherapy)
    return(pai)
  }
  V.t<-function(t)
  {
    Survival.adm<-Surv.adm.censor(t,n1,n2,A1,A2,tau)
    Survival.rdm<-exp(-h.cens*t)
    Survival.censor<-Survival.adm*Survival.rdm
    survival.control<-surv.control(t,rate0,k)
    hazard.control.value<-hazard.control(t,rate0,k)
    pdf.control<-hazard.control.value*survival.control
    pdf.immunotherapy<-pdf.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    V.t=(pc*pdf.control+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  mu.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.value<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]<-pai(t[i])*(1-pai(t[i]))*(hazard.control.value-hazard.immunotherapy.value)*V.t(t[i])/(pai(t[i])*hazard.control.value+(1-pai(t[i]))*hazard.immunotherapy.value)
    }
    return(integrand)
  }
  mu<-integrate(mu.integrand,lower=tstar.min,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol= 1e-02,stop.on.error=FALSE)$value
  sigma2.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])
    }
    return(integrand)
  }
  sigma2.tilde.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.value<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])*hazard.control.value*hazard.immunotherapy.value
      integrand[i]=integrand[i]/(pai(t[i])*hazard.control.value+(1-pai(t[i]))*hazard.immunotherapy.value)^2
    }
    return(integrand)
  }
  sigma2=integrate(sigma2.integrand,lower=0,upper=tau,subdivisions=300,rel.tol = .Machine$double.eps, abs.tol= 1e-02,stop.on.error=FALSE)$value
  sigma2.tilde=integrate(sigma2.tilde.integrand,lower=0,upper=tau,subdivisions=300,rel.tol = .Machine$double.eps, abs.tol= 1e-02,stop.on.error=FALSE)$value
  return(list(mu=mu,sigma2=sigma2,sigma2.tilde=sigma2.tilde))
}

## the function is used to estimate the number of events by the end of the each analysis without the adjustment of the sample size
death.number.fixed<-function(n,K,h.cens,A,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n: the number of the recruited subjects by the end of A
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A:the duration of recruitment
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
## tstar.max: the maximum possible delay time of an individual
{
  pc=1/(1+K)
  pt=K/(1+K)
  Survival.censor.comb<-function(t)
  {
    Survival.adm<-punif(t,tau-A,tau,lower.tail = FALSE)
    Survival.rdm<-exp(-h.cens*t)
    return(Survival.adm*Survival.rdm)
  }
  V.t<-function(t)
  {
    survival.control.vec<-surv.control(t,rate0,k)
    hazard.control.vec<-hazard.control(t,rate0,k)
    pdf.control.vec<-hazard.control.vec*survival.control.vec
    num=length(t)
    pdf.immunotherapy=rep(NA,num)
    for(i in 1:num)
    {
      pdf.immunotherapy[i]=pdf.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    }
    Survival.censor<-Survival.censor.comb(t)
    V.t=(pc*pdf.control.vec+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  Death.prop=integrate(V.t,lower=0,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
  Death.num=n*Death.prop
  return(Death.num)
}

## the following function is used to calculate the survival function of the time of the administrative censoring
Surv.adm.censor<-function(t,n1,n2,A1,A2,tau)
  ## t: the follow-up time
  ## n1: the sample size at the interim analysis
  ## n2: the sample size at the final analysis
  ## A1: the time of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## tau: the time of the final analysis
{
  ratio=n1/n2
  num=length(t)
  surv=rep(NA,num)
  for(i in 1:num)
  {
    if(t[i]<tau-A2)
    {
      surv[i]=1
    }
    else if(t[i]<tau-A1)
    {
      surv[i]=(1-ratio)/(A1-A2)*(t[i]+A1-tau)+ratio
    }
    else if(t[i]<tau)
    {
      surv[i]=ratio*(tau-t[i])/A1
    }
    else
    {
      surv[i]=0
    }
  }
  return(surv)
}

## the function is used to estimate the number of the events when the sample size is updated
death.number.updated<-function(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n1: the sample size at the interim analysis
  ## n2: the sample size at the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  # Death.recru.before.interim=n1*Death.proportion.expected(K,h.cens,A=A1,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  # Death.recru.after.interim=(n2-n1)*Death.proportion.expected(K,h.cens,A=(A2-A1),tau-A1,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  # Death.num=ceiling(Death.recru.before.interim+Death.recru.after.interim)
  pc=1/(1+K)
  pt=K/(1+K)
  V.t<-function(t)
  {
    survival.control.vec<-surv.control(t,rate0,k)
    hazard.control.vec<-hazard.control(t,rate0,k)
    pdf.control<-hazard.control.vec*survival.control.vec
    num=length(t)
    pdf.immunotherapy=rep(NA,num)
    for(i in 1:num)
    {
      pdf.immunotherapy[i]<-pdf.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    }
    Survival.adm<-Surv.adm.censor(t,n1,n2,A1,A2,tau)
    Survival.rdm<-exp(-h.cens*t)
    Survival.censor<-Survival.adm*Survival.rdm
    V.t=(pc*pdf.control+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  Death.prop=integrate(V.t,lower=0,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
  Death.num=Death.prop*n2
  return(Death.num)
}
#######################################################################################################################################
########################Part 3: Group sequential boundaries, power function and sample size determination #############################
#######################################################################################################################################

## the prediction of the time of interim analysis
interim.analysis.time.predict<-function(n2.min,d1,K,h.cens,A1.inf,A2,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n2.min: the initially planned sample size
  ## d1: the number of events by the end of the interim analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1.inf: the initially assumed time of the interim analysis
  ## A2: the duration of recruitment
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## alpha and beta: the shape parameters of the beta distribution
{
  root.function<-function(A1,n2.min,d1,K,h.cens,A2,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  {
    d.true=death.number.fixed(n2.min,K,h.cens,A2,tau=A1,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    diff=d.true-d1
    print(diff)
    return(diff)  
  }
  root=uniroot(root.function,n2.min=n2.min,d1=d1,K=K,h.cens=h.cens,A2=A2,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,lower=1/3*A1.inf,upper=3*A1.inf)$root
  return(root)
}

## the prediction of the time of final analysis
final.analysis.time.predict<-function(n2,d2,n1,K,h.cens,A1,A2,tau.inf,tau.sup,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n2: the maximum sample size
  ## d2: the initially number of events
  ## n1: the number of the patients who are recruited by the end of the interim analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis (a variable time; event-driven)
  ## A2: the duration of recruitment
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## alpha and beta: the shape parameters of the beta distribution
{
  root.function<-function(tau,n2,d2,n1,K,h.cens,A1,A2,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  {
    d.true=death.number.updated(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    diff=d.true-d2
    print(diff)
    return(diff)  
  }
  death.prop=d2/n2
  root=uniroot(root.function,n2=n2,d2=d2,n1=n1,K=K,h.cens=h.cens,A1=A1,A2=A2,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,lower=tau.inf,upper=tau.sup)$root
  return(root)
}

## the function is used to determine the group sequential boundaries
boundary.determination<-function(d1,d2,significance,method)
  ## d1: the number of events observed by the end of the interim analysis
  ## d2: the number of events observed by the end of the final analysis
  ## significance: the significance level
  ## method: the type of the spending function
  ## 1: the O'Brien-Fleming type spending function
  ## 2: the Pocock type spending function
{
  ## Two analyses are considered in order to compare with the promising zone design
  library(gsDesign)
  info.time<-d1/d2
  if(method==1)
  {
    gs<-gsDesign(k=2,test.type = 1,alpha=significance,sfu =sfLDOF,timing=info.time,n.I=c(info.time,1))
    Method="O'Brien & Fleming"
  }
  if(method==2)
  {
    gs<-gsDesign(k=2,test.type = 1,alpha=significance,sfu =sfLDPocock,timing=info.time,n.I=c(info.time,1))
    Method="Pocock"
  }
  boundary<-as.numeric(gs$upper$bound)## get the upper boundary of the group sequential design
  return(list(boundary=boundary,info.time=info.time,Method=Method))
}

## this function is used to calculate the power of the group sequential trial with the log-rank test
GsD.design.parameters<-function(n2,n1,K,h.cens,A1,d1,A2,d2,tau.inf,tau.sup,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,significance,method)
  ## n2: the sample size at the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the actual time of the interim analysis (determined by the recruitment)
  ## d1: the number of events occurring by the end of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## d2: the number of events by the end of the final analysis
  ## the final analysis time tau requires to be predicted
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## significance: the significance level
  ## method: the type of the spending function
  ## 1: the O'Brien-Fleming type spending function
  ## 2: the Pocock type spending function
{
  ## Two analyses are considered
  boundary.list=boundary.determination(d1,d2,significance,method)
  boundary=boundary.list$boundary
  death.number.vec=c(d1,d2)
  n.vec=c(n1,n2)
  list.dist.para<-list()
  list.dist.para[[1]]<-Dist.para.fixed.design(K,h.cens,A=A1,tau=A1,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  tau<-final.analysis.time.predict(n2,d2,n1,K,h.cens,A1,A2,tau.inf,tau.sup,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  list.dist.para[[2]]<-Dist.para.adaptive.design(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  mu.vector<-rep(NA,2)
  cov.matrix<-matrix(nrow=2,ncol=2)
  for(i in 1:2)
  {
    mu.vector[i]=sqrt(n.vec[i])*list.dist.para[[i]]$mu/sqrt(list.dist.para[[i]]$sigma2)
    for(j in 1:2)
    {
      if(i==j)
      {
        cov.matrix[i,i]=list.dist.para[[i]]$sigma2.tilde/list.dist.para[[i]]$sigma2
      }
      else if (i<j)
      {
        cov.matrix[i,j]=list.dist.para[[i]]$sigma2.tilde*n.vec[i]/sqrt(n.vec[i]*list.dist.para[[i]]$sigma2)/sqrt(n.vec[j]*list.dist.para[[j]]$sigma2)
      }
      else
      {
        cov.matrix[i,j]=list.dist.para[[j]]$sigma2.tilde*n.vec[j]/sqrt(n.vec[i]*list.dist.para[[i]]$sigma2)/sqrt(n.vec[j]*list.dist.para[[j]]$sigma2)
      }
    }
  }
  library("mvtnorm")
  power=as.numeric(1-pmvnorm(lower=-Inf,upper=boundary,mean=mu.vector,sigma=cov.matrix))
  power.interim=pnorm(boundary[1],mean=mu.vector[1],sd=sqrt(cov.matrix[1,1]),lower.tail = FALSE)
  #power.interim.ref=pnorm(sqrt(n.vec[1])*list.dist.para[[1]]$mu/sqrt(list.dist.para[[1]]$sigma2.tilde)-boundary[1]/sqrt(cov.matrix[1,1]))
  Ep.n=n1+(n2-n1)*(1-power.interim)
  Ep.d=death.number.vec[1]+(death.number.vec[2]-death.number.vec[1])*(1-power.interim)
  result=list(power=power,Ep.n=Ep.n,Ep.d=Ep.d,interim.bound=boundary[1],final.boundary=boundary[2],d1=death.number.vec[1],d2=death.number.vec[2],tau=tau)
  return(result)
}

## parallel function for that used to find the group sequential design matched to the corresponding promising zone design
Find.matched.gsd.parallel<-function(n2,n2.min,K,h.cens,A1,d1,A2,tau.inf,tau.sup,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,significance,Ep.d.tar,Ep.n.tar,method)
{
  n1=ceiling(n2.min/A2*A1) ## the sample size by the end of the interim analysis is event-driven
  A1.true=n1/n2.min*A2## the time of the interim analysis needs a minor adjustment due to the approximation of the sample size at the interim analysis
  d2.min=ceiling(death.number.updated(n1,n2,K,h.cens,A1.true,A2,tau.inf,rate0,k,lambda,tstar.min,tstar.max,alpha,beta))
  d2.max=floor(death.number.updated(n1,n2,K,h.cens,A1.true,A2,tau.sup,rate0,k,lambda,tstar.min,tstar.max,alpha,beta))
  ## if tau.sup is very large, a large proportion of subjects will randomly censored, and thus the number of events cannot be achieved if using the ceiling approximation
  d2.vec=seq(d2.min,d2.max)
  num.itr=length(d2.vec)
  result.matrix=matrix(nrow=length(d2.vec),ncol=9)
  colnames(result.matrix)=c("n2","tau","Ep.n","Ep.d","Index","interim.boundary","final.boundary","d1","d2")
  for(j in 1:num.itr)
  {
    result.matrix[j,1]=n2
    GSD<-GsD.design.parameters(n2=n2,n1=n1,K=K,h.cens=h.cens,A1=A1.true,d1=d1,A2=A2,d2=d2.vec[j],tau.inf,tau.sup,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,significance=significance,method=method)
    result.matrix[j,2]=GSD$tau
    result.matrix[j,3]=GSD$Ep.n
    result.matrix[j,4]=GSD$Ep.d
    result.matrix[j,5]=abs(GSD$Ep.d-Ep.d.tar)+abs(GSD$Ep.n-Ep.n.tar)
    result.matrix[j,6]=GSD$interim.bound
    result.matrix[j,7]=GSD$final.boundary
    result.matrix[j,8]=GSD$d1
    result.matrix[j,9]=GSD$d2
  }
  return(result.matrix)
}

## this function is used to find the group sequential design matched to the corresponding promising zone design
Find.matched.gsd<-function(n2.min,n2.vec,K,h.cens,A1,d1,A2,tau.inf,tau.sup,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,significance,Ep.d.tar,Ep.n.tar,method)
  ## n2.min: the minimum sample size by the end of the final analysis in the corresponding promising zone design
  ## n2.vec: a vector of possible sample size at the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## d2.min: the minimum number of events by the end of the final analysis
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value given the number of events)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## significance: the significance level
  ## Ep.d.tar: the target of the expected number of events
  ## Ep.n.tar: the target of the expected number of patients
  ## method: the type of the spending function
  ## 1: the O'Brien-Fleming type spending function
  ## 2: the Pocock type spending function
{
  num=length(n2.vec)
  library(parallel)
  varlist=c("GsD.design.parameters","boundary.determination","Dist.para.fixed.design","Dist.para.adaptive.design","death.number.fixed","death.number.updated","Surv.adm.censor","surv.control","hazard.control","surv.immuno","pdf.immuno","hazard.immuno","surv.immuno.ind","final.analysis.time.predict")
  core.num=detectCores(logical = FALSE)-1
  cl<-makeCluster(getOption("cl.cores",core.num))
  clusterExport(cl,varlist=varlist,envir=environment())
  Simul.res.list<-parLapplyLB(cl,n2.vec,Find.matched.gsd.parallel,n2.min=n2.min,K=K,h.cens=h.cens,A1=A1,d1=d1,A2=A2,tau.inf=tau.inf,tau.sup=tau.sup,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,significance=significance,Ep.d.tar=Ep.d.tar,Ep.n.tar=Ep.n.tar,method=method)
  stopCluster(cl)
  result=do.call(rbind,Simul.res.list)
  colnames(result)=c("n2","tau","Ep.n","Ep.d","Index","interim.boundary","final.boundary","d1","d2")
  Index=result[,5]
  index.num=which(Index==min(Index),arr.ind=TRUE)
  Select.result=result[index.num,]
  return(Select.result)
}

Find.matched.gsd.serial<-function(n2.min,n2.vec,K,h.cens,A1,d1,A2,tau.inf,tau.sup,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,significance,Ep.d.tar,Ep.n.tar,method)
{
  num=length(n2.vec)
  for(i in 1:num)
  {
    if(i==1)
    {
      result=Find.matched.gsd.parallel(n2=n2.vec[i],n2.min=n2.min,K=K,h.cens=h.cens,A1=A1,d1=d1,A2=A2,tau.inf=tau.inf,tau.sup=tau.sup,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,significance=significance,Ep.d.tar=Ep.d.tar,Ep.n.tar=Ep.n.tar,method=method)
    }
    else
    {
      result.itr=Find.matched.gsd.parallel(n2=n2.vec[i],n2.min=n2.min,K=K,h.cens=h.cens,A1=A1,d1=d1,A2=A2,tau.inf=tau.inf,tau.sup=tau.sup,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,significance=significance,Ep.d.tar=Ep.d.tar,Ep.n.tar=Ep.n.tar,method=method)
      result=rbind(result,result.itr)
    }
  }
  colnames(result)=c("n2","tau","Ep.n","Ep.d","Index","interim.boundary","final.boundary","d1","d2")
  Index=result[,5]
  index.num=which(Index==min(Index),arr.ind=TRUE)
  Select.result=result[index.num,]
  return(Select.result)
}

#####################################################################################
############################## Part 4: simulation code ##############################
#####################################################################################
## the function is used to generate the survival time of the subjects in the control group
rweibull<-function(n,rate0,k)
  ## -n:number of observations. If length(n) > 1, the length is taken to be the number required
  ## -rate0:rates before the time of change
  ## -k:the weibull shape parameter
{
  U<-runif(n)
  radnm<-(-log(U))^(1/k)/rate0
  return(radnm)
}

## the function is used to generate the survival time of the subjects in the immunotherapy group
rpweibull<-function(rate0,lambda,tstar,k)
  ## -n:number of observations. If length(n) > 1, the length is taken to be the number required
  ## -rate0:rates before the time of change
  ## -rate1:rates after the time of change
  ## -tstar:the time of change
  ## -k:the weibull shape parameter
{
  Ustar<-exp(-(rate0*tstar)^k)
  num=length(tstar)
  radnm=rep(NA,num)
  U<-runif(num)
  for(i in 1:num)
  {
    if(U[i]<Ustar[i])
    {
      radnm[i]<-((-log(U[i])+(lambda-1)*(rate0*tstar[i])^k)/lambda)^(1/k)/rate0
    }
    else
    {
      radnm[i]<-(-log(U[i]))^(1/k)/rate0
    }
  }
  return(radnm)
}

## produce the entry time points accroding to the Poisson process
rpoipross<-function(N,rate)
  ## -N:the number of time points
  ## -rate:intensity
{
  t=0
  S=rep(0,N)
  for(i in c(1:N))
  {
    U<-runif(1)
    t=t-log(U)/rate
    S[i]=t
  }
  return (S)
}

## This dataset is used to simulate the dataset used for the survival analysis
dataset.produce<-function(nc,nt,h.cens,A.start,A,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,hypothesis)
  ## nc: the sample size of the patients recruited in the control group during the period of [A.start,A.start+A]
  ## nt: the sample size of the patients recruited in the control group during the period of [A.start,A.start+A]
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A.start: the calendar time point at which the recruitment of nc+nt subjects starts since the beginning of the clinical trial
  ## A: the duration of the recruitment
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
## hypothesis:0, the dataset is produced under the null hypothesis; 1, the dataset is produced under the alternative hypothesis
{
  datasetc<-matrix(ncol=7,nrow=nc)
  datasett<-matrix(ncol=7,nrow=nt)
  datasetc[,1]=rep(1,nc)## "1" represents the control group 
  datasett[,1]=rep(0,nt)## "0" represents the immunotherapy group 
  datasetc[,2]=rweibull(nc,rate0,k)## produce the survival time of the control group
  if(hypothesis==0)
  {
    datasett[,2]=rweibull(nt,rate0,k)## produce the survival time of the control group under the null hypothesis
  }
  else
  {
    tstar.vec=tstar.min+(tstar.max-tstar.min)*rbeta(nt,alpha,beta)## produce the individual delay time
    datasett[,2]=rpweibull(rate0,lambda,tstar.vec,k)
  }
  ##produce the entry time of control group and treatment group by poisson process
  entry=rpoipross(nc+nt,(nc+nt)/A)
  entry.total.order=c(1:(nc+nt))## original order number of two groups
  entry.control.order=sample(entry.total.order,nc)## select the order number corresponding to the entry time of the control group randomly
  entry.treatment.order=entry.total.order[-match(entry.control.order,entry.total.order)]## the rest is the order number of the treatment group
  entry.treatment.order=entry.treatment.order[sample(1:nt)]## permutate the order number of the treatment group
  ## Note: the recruitment time need to transformed the calendar time since the beginning of the clinical trial
  datasetc[,3]=A.start+entry[entry.control.order]## get the entry number of the control group
  datasett[,3]=A.start+entry[entry.treatment.order]## get the entry number of the treatment group
  ## produce the random censoring time
  datasetc[,4]=rexp(nc,h.cens)
  datasett[,4]=rexp(nt,h.cens)
  ## if the survial time is longer than the random censor time,the subject is censored (denoted by 0);uncersored vice versa (denoted by 1)
  datasetc[,5]=datasetc[,2]<datasetc[,4]
  datasett[,5]=datasett[,2]<datasett[,4]
  ## obtain the observation time since the recruitment of patients
  datasetc[,6]=apply(cbind(datasetc[,2],datasetc[,4]),1,min)
  datasett[,6]=apply(cbind(datasett[,2],datasett[,4]),1,min)
  ## obtain the observed time since the beginning of the clinical trial
  ## Note: the recruitment starts at the calendar time of A.start which has been added to the observation time in the recruitment time
  ## thus it does not required to be added in the observation time since the beginning of the clinical trial again!!!
  datasetc[,7]=datasetc[,6]+datasetc[,3]
  datasett[,7]=datasett[,6]+datasett[,3]
  dataset.cb0=rbind(datasett,datasetc)## combine two datasets
  dataset.cb=dataset.cb0[order(dataset.cb0[,7]),]## sort the matrix by the column,which represents "the end calendar time of actual visit"
  dataset.whole.1.0=matrix(nrow=nc+nt,ncol=8)## the whole dataset of the control arm and the treatment arm 
  dataset.whole.1.0[,1]=seq(1,nc+nt)## the order number of two groups
  dataset.whole.1.0[,2:8]=dataset.cb##the data need to store
  colnames(dataset.whole.1.0)=c("order.number","group","survival.time","entry.time","censorring.time","censor.or.death","actual.observed.time.since.recruitment","actual.observed.time.since.begining")
  return(dataset.whole.1.0)
}

##implement the log-rank test
log.rank.test<-function(dataset.input)
  ## dataset.input is produced by the dataset.produce process
{
  dataset.analysis<-dataset.input[,c(2,7,6)]
  dataset.analysis<-dataset.analysis[order(dataset.analysis[,2]),]
  dataset.cum<-NA
  record.begin=0
  num.tot<-length(dataset.analysis[,1])
  num.itr<-num.tot
  num.trt<-sum(dataset.analysis[,1]==0)#0 stands for the immunotherapy group
  num.ctr<-sum(dataset.analysis[,1]==1)#1 stands for the control group
  for(i in 1:num.tot)
  {
    if(i==1||dataset.analysis[i,2]!=dataset.analysis[i-1,2])
    {
      death.vector<-c(0,0,0)
      if(dataset.analysis[i,3]==1)
      {
        if(dataset.analysis[i,1]==1)##1 stands for the control group
        {
          death.vector[1]=1
        }
        else if(dataset.analysis[i,1]==0)##0 stands for the immunotherapy group
        {
          death.vector[2]=1
        }
        death.vector[3]=1
      }
      itr.ele=c(dataset.analysis[i,2],num.ctr,num.trt,num.itr,death.vector)
    }
    else if(dataset.analysis[i,2]==dataset.analysis[i-1,2])
    {
      death.vector.add<-c(0,0,0)
      if(dataset.analysis[i,3]==1)
      {
        if(dataset.analysis[i,1]==1)
        {
          death.vector.add[1]=1
        }
        else if(dataset.analysis[i,1]==0)
        {
          death.vector.add[2]=1
        }
        death.vector.add[3]=1
      }
      death.vector=death.vector+death.vector.add
      itr.ele=c(dataset.analysis[i,2],num.ctr,num.trt,num.itr,death.vector)
    }
    if(record.begin==0)
    {
      if(dataset.analysis[i,3]==1&dataset.analysis[i,2]!=dataset.analysis[i+1,2])
      {
        dataset.cum=itr.ele
        record.begin=1
      }
    }
    else if(i<num.tot)
    {
      if(dataset.analysis[i,3]==1&dataset.analysis[i,2]!=dataset.analysis[i+1,2])
      {
        dataset.cum=rbind(dataset.cum,itr.ele)
      }
    }
    else if(dataset.analysis[i,3]==1&i==num.tot)
    {
      dataset.cum=rbind(dataset.cum,itr.ele)
    }
    num.itr=num.itr-1
    if(dataset.analysis[i,1]==1)
    {
      num.ctr=num.ctr-1
    }
    else
    {
      num.trt=num.trt-1
    }
  }
  colnames(dataset.cum)<-c("Survival.time","num.ctr","num.trt","num.tot","death.ctr","death.trt","death.tot")
  num.dist<-length(dataset.cum[,1])
  Sw=matrix(0,nrow=num.dist,ncol=3)
  for(i in 1:(num.dist-1))
  {
    Sw[i,1]=i
    d1j=dataset.cum[i,5]
    dj=dataset.cum[i,7]
    n1j=dataset.cum[i,2]
    n2j=dataset.cum[i,3]
    nj=n1j+n2j
    e1j=n1j*dj/nj
    nume.add=d1j-e1j
    denume.add=n1j*n2j*dj*(nj-dj)/nj^2/(nj-1)
    if(i!=1)
    {
      Sw[i,2]=Sw[i-1,2]+nume.add
      Sw[i,3]=Sw[i-1,3]+denume.add
    }
    else
    {
      Sw[i,2]=nume.add
      Sw[i,3]=denume.add
    }
  }
  Sw[num.dist,1]=num.dist
  d1j=dataset.cum[num.dist,5]
  dj=dataset.cum[num.dist,7]
  n1j=dataset.cum[num.dist,2]
  n2j=dataset.cum[num.dist,3]
  nj=n1j+n2j
  e1j=n1j*dj/nj
  nume.add=d1j-e1j
  denume.add=n1j*n2j*dj/nj^2
  Sw[num.dist,2]=Sw[num.dist-1,2]+nume.add
  Sw[num.dist,3]=Sw[num.dist-1,3]+denume.add
  ##get the value of the log-rank statistics corresponding to interim analysis and final analysis
  Sw_used=Sw[num.dist,]
  Sw<-Sw_used[2]/sqrt(Sw_used[3])## calculate the standardized value of the piecewise weitghted log-rank test statistics
  return(Sw)
}

library(parallel)
maximum.information.trial.one.simulation<-function(order,K,n2.min,n2,d1,d2,h.cens,A2,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,hypothesis)
  ## order: the order number of simulated adpative trial
  ## K:the allocation ratio of the immunotherapy and control groups
  ## n2.min: the initial sample size in the corresponding promising zone design
  ## n2: the actual maximum sample size of the group sequential trial
  ## d1:the number of the events by the end of the interim analysis
  ## d2:the initial assumed number of the events by the end of the final analysis
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A2: the time of the end of the recruitment
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## alpha and beta are the actual values
  ## hypothesis??0, the null hypothesis; 1, the alternative hypothesis.
{
  n2c.min=round(n2.min/(K+1))
  n2t.min=n2.min-n2c.min
  dataset.interim<-dataset.produce(n2c.min,n2t.min,h.cens,A.start=0,A=A2,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,hypothesis)
  death.cum.vec<-cumsum(dataset.interim[,6])
  order.num=min(sum(death.cum.vec<d1)+1,n2.min)
  analysis.time=as.numeric(dataset.interim[order.num,8])## The calendar time of the interim analysis is event-driven by d1;
  Interim.time=analysis.time
  dataset.interim<-dataset.interim[dataset.interim[,4]<=analysis.time,]
  n1=nrow(dataset.interim)## the sample size recruited at the interim analysis is event-driven
  dataset.interim.copy=dataset.interim## No administrative censoring; the dataset is copied for the final analysis
  dataset.interim[dataset.interim[,8]>analysis.time,6]=0
  dataset.interim[dataset.interim[,8]>analysis.time,7]=analysis.time-dataset.interim[dataset.interim[,8]>analysis.time,4]
  dataset.interim[dataset.interim[,8]>analysis.time,8]=analysis.time
  z1=log.rank.test(dataset.interim)
  n.extra=n2-n1
  nc.extra=round(n.extra/(K+1))
  nt.extra=n.extra-nc.extra
  dataset.extra<-dataset.produce(nc.extra,nt.extra,h.cens,A.start=Interim.time,A=A2-Interim.time,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,hypothesis)
  dataset.whole=rbind(dataset.interim.copy,dataset.extra)
  unordered.observation.time=dataset.whole[,8]
  order.vector=order(unordered.observation.time)
  dataset.whole=dataset.whole[order.vector,]## The combined dataset need to be reordered by the observation time since the beginning of the clinical trial
  death.cum.vec<-cumsum(dataset.whole[,6])
  order.num=min(sum(death.cum.vec<d2)+1,n2)
  analysis.time=as.numeric(dataset.whole[order.num,8])## The calendar time of the interim analysis is event-driven by d1;
  Final.time=analysis.time
  dataset.analysis<-dataset.whole[dataset.whole[,4]<=analysis.time,]
  n2.act=nrow(dataset.analysis)
  dataset.analysis[dataset.analysis[,8]>analysis.time,6]=0
  dataset.analysis[dataset.analysis[,8]>analysis.time,7]=analysis.time-dataset.analysis[dataset.analysis[,8]>analysis.time,4]
  dataset.analysis[dataset.analysis[,8]>analysis.time,8]=analysis.time
  z2=log.rank.test(dataset.analysis)
  Sw_value=c(z1,z2)
  Total.number.vec=c(n1,n2.act)
  tau.vec=c(Interim.time,Final.time)
  c(order=order,Sw_value=Sw_value,Total.number.vec=Total.number.vec,tau.vec=tau.vec)
}

maximum.information.trial.Monte.Carlo.simulation.parallel<-function(K,n2.min,n2,d1,d2,h.cens,A2,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,hypothesis,boundary,simnum)
  ## K:the allocation ratio of the immunotherapy and control groups
  ## n2.min: the initial sample size in the corresponding promising zone design
  ## n2: the actual maximum sample size of the group sequential trial
  ## d1:the number of the events by the end of the interim analysis
  ## d2:the initial assumed number of the events by the end of the final analysis
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A2: the time of the end of the recruitment
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## alpha and beta are the actual values
  ## hypothesis??0, the null hypothesis; 1, the alternative hypothesis.
  ## hypothesis:0 the dataset is generated under the null hypothesis;
  ## hypothesis:1 the dataset is generated under the alternative hypothesis;
  ## boundary: the group sequential boundary
  ## simnum: the number of simulation repetitions
{
  numberVisits=2
  Decision.simulation=matrix(0,nrow=simnum,ncol=numberVisits)
  varlist=c("log.rank.test","maximum.information.trial.one.simulation","dataset.produce","rpoipross","rweibull","rpweibull")
  library(parallel)
  ## core.num: the number of the CPU cores used for the parallel computation
  core.num=detectCores(logical = FALSE)-1
  cl<-makeCluster(getOption("cl.cores",core.num))
  clusterExport(cl,varlist=varlist,envir=environment())
  Simul.res.list<-parLapply(cl,seq(1,simnum,1),maximum.information.trial.one.simulation,K=K,n2.min=n2.min,n2=n2,d1=d1,d2=d2,h.cens=h.cens,A2=A2,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,hypothesis=hypothesis)
  stopCluster(cl)
  Simul.res <- do.call(rbind,Simul.res.list)
  test.statistics.simulation=Simul.res[,seq(1,numberVisits)+1]
  Total.number.simulation=Simul.res[,seq(numberVisits+2,numberVisits*2+1)]
  tau.vec.simulation=Simul.res[,seq(numberVisits*2+2,numberVisits*3+1)]
  for(l in 1:simnum)
  {
    Sw_value=test.statistics.simulation[l,]
    reject.decision=Sw_value>boundary
    for(i in 1:(numberVisits-1))## once the hypothesis is rejected in one interim ananlysis,the following interim analyses and final analysis won't be conducted,so let them be 0
    {
      if(reject.decision[i]==1)
      {
        for(j in c((i+1):numberVisits))
        {
          reject.decision[j]=0
          Total.number.simulation[l,j]=0
          tau.vec.simulation[l,j]=0
        }
        break
      }
    }
    Decision.simulation[l,]=reject.decision
  }
  times.reject.respective<-apply(Decision.simulation,2,sum)
  times.reject<-sum(times.reject.respective)
  Power=times.reject/simnum## total exprical power
  Power.respective=times.reject.respective/simnum## emprical power correspongding to respective stage
  Power.cumulative=rep(0,k)## cumulative emprical power correspongding to respective stage
  Power.cumulative[1]=Power.respective[1]
  for(i in 2:numberVisits)
  {
    Power.cumulative[i]=Power.cumulative[i-1]+Power.respective[i]
  }
  ## calculate the empirical means of the calendar time of every analysis
  ## calculate the empirical means of the cumulative numbers of the recruited patients at every analysis
  tau.vec.mean.simulation=rep(0,numberVisits)
  Total.mean.cumulative.simulation=rep(0,numberVisits)
  for(i in 1:numberVisits)
  {
    Vector.tau.simulation=tau.vec.simulation[,i]
    Vector.Total.number.simulation=Total.number.simulation[,i]
    tau.vec.mean.simulation[i]=mean(Vector.tau.simulation[Vector.tau.simulation!=0])
    Total.mean.cumulative.simulation[i]=mean(Vector.Total.number.simulation[Vector.Total.number.simulation!=0])
  }
  ## calculate the mean of the duration of the whole clinical trial
  ## calculate the average number of actual enrolled patients
  tau.simulation=rep(0,simnum)
  Total.patients.number.simulation=rep(0,simnum)
  Total.events.number.simulation=rep(0,simnum)
  for(l in 1:simnum)
  {
    tau.simulation[l]=max(tau.vec.simulation[l,])
    Total.patients.number.simulation[l]=max(Total.number.simulation[l,])
    Total.events.number.simulation[l]=d1*Decision.simulation[l,1]+d2*(1-Decision.simulation[l,1])
  }
  tau.average.simulation=mean(tau.simulation)
  Average.patients.number.simulation=mean(Total.patients.number.simulation)
  Average.events.number.simulation=mean(Total.events.number.simulation)
  mean.test.statistics.std=apply(test.statistics.simulation,2,mean)
  Var.test.statistics.matrix.std=matrix(nrow=numberVisits,ncol=numberVisits)
  for(i in 1:numberVisits)
  {
    for(j in 1:numberVisits)
    {
      Var.test.statistics.matrix.std[i,j]=cov(test.statistics.simulation[,i],test.statistics.simulation[,j])
    }
  }
  Distribution.list<-list(mean.test.statistics.std=mean.test.statistics.std,Var.test.statistics.matrix.std=Var.test.statistics.matrix.std)
  Original.Data=list(test.statistics.simulation=test.statistics.simulation)
  Power.list<-list(Power=Power,Power.respective=Power.respective,Power.cumulative=Power.cumulative)
  Parameters.list<-list(K=K,n2=n2,d1=d1,d2=d2,h.cens=h.cens,A2=A2,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,hypothesis=hypothesis,boundary=boundary,simnum=simnum)
  Empirical.design.parameters=list(tau.vec.mean.simulation=tau.vec.mean.simulation,Total.mean.cumulative.simulation=Total.mean.cumulative.simulation,tau.average.simulation=tau.average.simulation,Average.patients.number.simulation=Average.patients.number.simulation,Average.events.number.simulation=Average.events.number.simulation)
  return(list(Parameters.list=Parameters.list,Power.list=Power.list,Distribution.list=Distribution.list,Original.Data=Original.Data,Empirical.design.parameters=Empirical.design.parameters))
}
