######################################################
############## Part 1:survival model #################
######################################################

## the survival function of the control group
surv.control<-function(t,rate0,k)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
{
  return(exp(-(rate0*t)^k))
}

## the hazard function of the control group
hazard.control<-function(t,rate0,k)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
{
  return(k*rate0^k*t^(k-1))
}

## the survival function of an individual in the immunotherapy group
## assuming a piece-wise Weibull distribution with the fixed delay time
surv.immuno.ind<-function(t,rate0,k,lambda1,lambda2,tstar)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## tstar: the delay time of an individual
{
  Surv<-(t<tstar)*exp(-lambda1*(rate0*t)^k)+(t>=tstar)*exp((lambda2-lambda1)*(rate0*tstar)^k-lambda2*(rate0*t)^k)
  return(Surv)
}

## the probability function of an individual in the immunotherapy group
## assuming a piece-wise Weibull distribution with the fixed delay time
pdf.immuno.ind<-function(t,rate0,k,lambda1,lambda2,tstar)
{
  pdf<-(t<tstar)*lambda1*k*rate0^k*t^(k-1)*exp(-lambda1*(rate0*t)^k)+(t>=tstar)*lambda2*k*rate0^k*t^(k-1)*exp((lambda2-lambda1)*(rate0*tstar)^k-lambda2*(rate0*t)^k)
  return(pdf)
}
## the survival function of the overall immunotherapy group
surv.immuno<-function(t,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  if(tstar.min==tstar.max)
  {
    Surv<-surv.immuno.ind(t,rate0,k,lambda1,lambda2,tstar.min)
  }
  else
  {
    integrand<-function(tstar)
    {
      tstar.std=(tstar-tstar.min)/(tstar.max-tstar.min)
      value=surv.immuno.ind(t,rate0,k,lambda1,lambda2,tstar)*dbeta(tstar.std,shape1=alpha,shape2=beta)/(tstar.max-tstar.min)
      ##Note: after the scale transformation of the random variables, the deriviates between the new and old random variables need to be multiplied
      return(value)
    }
    after.onset<-integrate(integrand,lower=tstar.min,upper=t,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
    t.std=(t-tstar.min)/(tstar.max-tstar.min)
    before.onset<-pbeta(t.std,shape1=alpha,shape2=beta,lower.tail=FALSE)*exp(-lambda1*(rate0*t)^k)
    Surv<-after.onset+before.onset
  }
  return(Surv)
}

## the probability density function of the overall immunotherapy group
pdf.immuno<-function(t,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  if(tstar.min==tstar.max)
  {
    pdf<-pdf.immuno.ind(t,rate0,k,lambda1,lambda2,tstar.min)
  }
  else
  {
    integrand<-function(tstar)
    {
      tstar.std=(tstar-tstar.min)/(tstar.max-tstar.min)
      value=pdf.immuno.ind(t,rate0,k,lambda1,lambda2,tstar)*dbeta(tstar.std,shape1=alpha,shape2=beta)/(tstar.max-tstar.min)
      ##Note: after the scale transformation of the random variables, the deriviates between the new and old random variables need to be multiplied
      return(value)
    }
    after.onset<-integrate(integrand,lower=tstar.min,upper=t,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
    t.std=(t-tstar.min)/(tstar.max-tstar.min)
    before.onset<-pbeta(t.std,shape1=alpha,shape2=beta,lower.tail=FALSE)*exp(-lambda1*(rate0*t)^k)*lambda1*k*rate0^k*t^(k-1)
    pdf<-after.onset+before.onset
  }
  return(pdf)
}

##the hazard function of the overall immunotherapy group
hazard.immuno<-function(t,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta)
  ## t:the survival time
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  pdf<-pdf.immuno(t,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta)
  surv<-surv.immuno(t,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta)
  return(pdf/surv)
}


#####################################################################
############## Part 2:Distribution and death number #################
#####################################################################


## the following function is used to calculate the distribution of the log-rank test statistics at the each analysis without the sample size adjustment
Dist.para.fixed.design<-function(K,h.cens,A,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A:the duration of recruitment
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
{
  pc=1/(1+K)
  pt=K/(1+K)
  Survival.censor.comb<-function(t)
  {
    Survival.adm<-punif(t,tau-A,tau,lower.tail = FALSE)
    Survival.rdm<-exp(-h.cens*t)
    return(Survival.adm*Survival.rdm)
  }
  pai<-function(t)
  {
    survival.control<-surv.control(t,rate0,k)
    survival.immunotherapy<-surv.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    pai=pc*survival.control/(pc*survival.control+pt*survival.immunotherapy)
    return(pai)
  }
  V.t<-function(t)
  {
    survival.control<-surv.control(t,rate0,k)
    hazard.control.value<-hazard.control(t,rate0,k)
    pdf.control<-hazard.control.value*survival.control
    pdf.immunotherapy<-pdf.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    Survival.censor<-Survival.censor.comb(t)
    V.t=(pc*pdf.control+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  mu.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.vec<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]<-pai(t[i])*(1-pai(t[i]))*(hazard.control.vec-hazard.immunotherapy.value)*V.t(t[i])/(pai(t[i])*hazard.control.vec+(1-pai(t[i]))*hazard.immunotherapy.value)
    }
    return(integrand)
  }
  mu=integrate(mu.integrand,lower=tstar.min,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
  sigma2.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])
    }
    return(integrand)
  }
  sigma2.tilde.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.value<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])*hazard.control.value*hazard.immunotherapy.value
      integrand[i]=integrand[i]/(pai(t[i])*hazard.control.value+(1-pai(t[i]))*hazard.immunotherapy.value)^2
    }
    return(integrand)
  }
  sigma2=integrate(sigma2.integrand,lower=0,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol= 1e-02,stop.on.error=FALSE)$value
  sigma2.tilde=integrate(sigma2.tilde.integrand,lower=0,upper=tau,subdivisions=300,rel.tol = .Machine$double.eps, abs.tol= 1e-02,stop.on.error=FALSE)$value
  return(list(mu=mu,sigma2=sigma2,sigma2.tilde=sigma2.tilde))
}

## the function is used to estimate the number of events by the end of the each analysis without the adjustment of the sample size
Death.number.expected<-function(n,K,h.cens,A,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n: the number of the recruited subjects by the end of A
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A:the duration of recruitment
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
## tstar.max: the maximum possible delay time of an individual
{
  pc=1/(1+K)
  pt=K/(1+K)
  Survival.censor.comb<-function(t)
  {
    Survival.adm<-punif(t,tau-A,tau,lower.tail = FALSE)
    Survival.rdm<-exp(-h.cens*t)
    return(Survival.adm*Survival.rdm)
  }
  V.t<-function(t)
  {
    survival.control.vec<-surv.control(t,rate0,k)
    hazard.control.vec<-hazard.control(t,rate0,k)
    pdf.control.vec<-hazard.control.vec*survival.control.vec
    num=length(t)
    pdf.immunotherapy=rep(NA,num)
    for(i in 1:num)
    {
      pdf.immunotherapy[i]=pdf.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    }
    Survival.censor<-Survival.censor.comb(t)
    V.t=(pc*pdf.control.vec+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  Death.prop=integrate(V.t,lower=0,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
  Death.num=n*Death.prop
  return(Death.num)
}

## the following function is used to calculate the survival function of the time of the administrative censoring
Surv.adm.censor<-function(t,n1,n2,A1,A2,tau)
  ## t: the follow-up time
  ## n1: the sample size at the interim analysis
  ## n2: the sample size at the final analysis
  ## A1: the time of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## tau: the time of the final analysis
{
  ratio=n1/n2
  num=length(t)
  surv=rep(NA,num)
  for(i in 1:num)
  {
    if(t[i]<tau-A2)
    {
      surv[i]=1
    }
    else if(t[i]<tau-A1)
    {
      surv[i]=(1-ratio)/(A1-A2)*(t[i]+A1-tau)+ratio
    }
    else if(t[i]<tau)
    {
      surv[i]=ratio*(tau-t[i])/A1
    }
    else
    {
      surv[i]=0
    }
  }
  return(surv)
}

## the function is used to estimate the number of the events when the sample size is updated
death.number.updated<-function(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n1: the sample size at the interim analysis
  ## n2: the sample size at the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
## tstar.min: the minimum possible delay time of an individual
## tstar.max: the maximum possible delay time of an individual
{
  # Death.recru.before.interim=n1*Death.proportion.expected(K,h.cens,A=A1,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  # Death.recru.after.interim=(n2-n1)*Death.proportion.expected(K,h.cens,A=(A2-A1),tau-A1,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  # Death.num=ceiling(Death.recru.before.interim+Death.recru.after.interim)
  pc=1/(1+K)
  pt=K/(1+K)
  V.t<-function(t)
  {
    survival.control.vec<-surv.control(t,rate0,k)
    hazard.control.vec<-hazard.control(t,rate0,k)
    pdf.control<-hazard.control.vec*survival.control.vec
    num=length(t)
    pdf.immunotherapy=rep(NA,num)
    for(i in 1:num)
    {
      pdf.immunotherapy[i]<-pdf.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    }
    Survival.adm<-Surv.adm.censor(t,n1,n2,A1,A2,tau)
    Survival.rdm<-exp(-h.cens*t)
    Survival.censor<-Survival.adm*Survival.rdm
    V.t=(pc*pdf.control+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  Death.prop=integrate(V.t,lower=0,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol=1e-02,stop.on.error=FALSE)$value
  Death.num=Death.prop*n2
  return(Death.num)
}

## the following function is used to calculate the distribution of the log-rank test statistics at the final analysis of the adaptive design
Dist.para.adaptive.design<-function(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n1: the sample size at the interim analysis
  ## n2: the sample size at the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
  ## tau:the duration of the whole clinical trial
  ## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
## tstar.min: the minimum possible delay time of an individual
## tstar.max: the maximum possible delay time of an individual
{
  pc=1/(1+K)
  pt=K/(1+K)
  pai<-function(t)
  {
    survival.control<-surv.control(t,rate0,k)
    survival.immunotherapy<-surv.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    pai=pc*survival.control/(pc*survival.control+pt*survival.immunotherapy)
    return(pai)
  }
  V.t<-function(t)
  {
    Survival.adm<-Surv.adm.censor(t,n1,n2,A1,A2,tau)
    Survival.rdm<-exp(-h.cens*t)
    Survival.censor<-Survival.adm*Survival.rdm
    survival.control<-surv.control(t,rate0,k)
    hazard.control.value<-hazard.control(t,rate0,k)
    pdf.control<-hazard.control.value*survival.control
    pdf.immunotherapy<-pdf.immuno(t,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    V.t=(pc*pdf.control+pt*pdf.immunotherapy)*Survival.censor
    return(V.t)
  }
  mu.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.value<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]<-pai(t[i])*(1-pai(t[i]))*(hazard.control.value-hazard.immunotherapy.value)*V.t(t[i])/(pai(t[i])*hazard.control.value+(1-pai(t[i]))*hazard.immunotherapy.value)
    }
    return(integrand)
  }
  mu<-integrate(mu.integrand,lower=tstar.min,upper=tau,subdivisions=300,rel.tol=.Machine$double.eps,abs.tol= 1e-02,stop.on.error=FALSE)$value
  sigma2.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])
    }
    return(integrand)
  }
  sigma2.tilde.integrand<-function(t)
  {
    num=length(t)
    integrand=rep(NA,num)
    for(i in 1:num)
    {
      hazard.control.value<-hazard.control(t[i],rate0,k)
      hazard.immunotherapy.value<-hazard.immuno(t[i],rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
      integrand[i]=pai(t[i])*(1-pai(t[i]))*V.t(t[i])*hazard.control.value*hazard.immunotherapy.value
      integrand[i]=integrand[i]/(pai(t[i])*hazard.control.value+(1-pai(t[i]))*hazard.immunotherapy.value)^2
    }
    return(integrand)
  }
  sigma2=integrate(sigma2.integrand,lower=0,upper=tau,subdivisions=300,rel.tol = .Machine$double.eps, abs.tol= 1e-02,stop.on.error=FALSE)$value
  sigma2.tilde=integrate(sigma2.tilde.integrand,lower=0,upper=tau,subdivisions=300,rel.tol = .Machine$double.eps, abs.tol= 1e-02,stop.on.error=FALSE)$value
  return(list(mu=mu,sigma2=sigma2,sigma2.tilde=sigma2.tilde))
}

###############################################################################
###################### Part 3  On sample size re-estimation ###################
###############################################################################

## the function is used to calculate the updated boundary of the final analysis
bound.determination.in.adaptive.design<-function(significance,z1,d1,d2,d2.new)
  ## significance: the significance level
  ## z1:the value of the log-rank test statistics at the interim analysis
  ## d1:the number of the events by the end of the interim analysis
  ## d2:the initial assumed number of the events by the end of the final analysis
  ## d2.new: the updated number of the events by the end of final analysis
{
  z.sig=qnorm(1-significance)
  boundary.new<-(z.sig*sqrt(d2)-z1*sqrt(d1))*sqrt(d2.new-d1)/sqrt(d2-d1)+z1*sqrt(d1)
  boundary.new<-boundary.new/sqrt(d2.new)
}

## the function is used to calculate the conditional power given the value of the log-rank test statistics at the interim analysis
Conditional.power.adaptive.design<-function(n1,n2,significance,z1,d1,d2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n1: the sample size at the interim analysis
  ## n2: the sample size at the final analysis
  ## significance: the significance level
  ## z1:the value of the standardized log-rank test statistics at the interim analysis
  ## d1:the number of the events by the end of the interim analysis
  ## d2:the initial assumed number of the events by the end of the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis (event-driven; thus, not fixed)
  ## A2: the time of the end of the recruitment
  ## assume A1<A2
## tau:the duration of the whole clinical trial
## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
## rate0: the hazard parameter of the control group
## k:the shape parameter
## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
## tstar.min: the minimum possible delay time of an individual
## tstar.max: the maximum possible delay time of an individual
{
  d2.new<-ceiling(death.number.updated(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta))
  bound<-bound.determination.in.adaptive.design(significance,z1,d1,d2,d2.new)
  list.dist.interim<-Dist.para.fixed.design(K,h.cens,A1,A1,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  mu.interim<-list.dist.interim$mu
  sigma2.interim<-list.dist.interim$sigma2
  sigma2.tilde.interim<-list.dist.interim$sigma2.tilde
  list.dist.final<-Dist.para.adaptive.design(n1,n2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  mu.final<-list.dist.final$mu
  sigma2.final<-list.dist.final$sigma2
  sigma2.tilde.final<-list.dist.final$sigma2.tilde
  cpower.z=n2*mu.final-n1*mu.interim+z1*sqrt(n1*sigma2.interim)-bound*sqrt(n2*sigma2.final)
  cpower.z=cpower.z/sqrt(n2*sigma2.tilde.final-n1*sigma2.tilde.interim)
  cpower=pnorm(cpower.z)
  return(list(cpower=cpower,d2.new=d2.new,bound=bound))
}

## the function is used to determine the minimum possible sample size at the final analysis in the adaptive design
## the minimum sample size is the sample size for the fixed sample trial with the optimistic scenario 
n2min.determination.adaptive.design<-function(significance,power,K,h.cens,A1,A2,tau,rate0,k,lambda.min,tstar.min)
  ## significance: the significance level
  ## power: the nominal power
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the latest time of the interim analysis
  ## A2: the recruitment period
  ## tau:the duration of the whole clinical trial
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda.min: the minimum hazard ratio of the immunotherapy and control groups after the full onset of effect
  ## the delay time is assumed to be the minimum delay time, namely tstar.min.
{
  list.dist.final<-Dist.para.fixed.design(K,h.cens,A2,tau,rate0,k,lambda.min,tstar.min,tstar.min,NA,NA)
  mu.final<-list.dist.final$mu
  sigma.final<-sqrt(list.dist.final$sigma2)
  sigma.tilde.final<-sqrt(list.dist.final$sigma2.tilde)
  n2.min=ceiling((sigma.final*qnorm(1-significance)+sigma.tilde.final*qnorm(power))^2/mu.final^2)
  n1=ceiling(n2.min*A1/A2)
  d1=ceiling(Death.number.expected(n2.min,K,h.cens,A2,A1,rate0,k,lambda.min,tstar.min,tstar.min,NA,NA))
  d2=ceiling(Death.number.expected(n2.min,K,h.cens,A2,tau,rate0,k,lambda.min,tstar.min,tstar.min,NA,NA))
  result=list(d1=d1,d2=d2,n1=n1,n2.min=n2.min)
  return(result)
  
}

## the function is used to re-estimate the required maximum sample size in the adpaptive design
## Note: the conditional power is always monotonously increasing with the sample size
n2.reestimation.adpative.design<-function(n1,n2.min,n2.max,significance,z1,d1,d2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,power)
  ## n1: the sample size at the interim analysis
  ## n2.min: the initial specification of the sample size at the final analysis
  ## n2.max: the maximum sample size at the final analysis
  ## significance: the significance level
  ## z1:the value of the standardized log-rank test statistics at the interim analysis
  ## d1:the number of the events by the end of the interim analysis
  ## d2:the initial assumed number of the events by the end of the final analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis (event-driven; thus, not fixed)
  ## A2: the time of the end of the recruitment
## assume A1<A2
## tau:the duration of the whole clinical trial
## (note: the clinical trial is event-driven, so the value of tau needs to be updated by the predicted value)
## rate0: the hazard parameter of the control group
## k:the shape parameter
## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
## tstar.min: the minimum possible delay time of an individual
## tstar.max: the maximum possible delay time of an individual
## power: the nominal power
{
  
  root.function<-function(n1,n2,significance,z1,d1,d2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,power)
  {
    diff=Conditional.power.adaptive.design(n1,n2,significance,z1,d1,d2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)$cpower-power
    print(diff)
    return(diff)  
  }
  n2.new=uniroot(root.function,n1=n1,significance=significance,z1=z1,d1=d1,d2=d2,K=K,h.cens=h.cens,A1=A1,A2=A2,tau=tau,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,power=power,lower=n2.min,upper=n2.max)$root
  n2.new=ceiling(n2.new)
  res.list=Conditional.power.adaptive.design(n1,n2.new,significance,z1,d1,d2,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  cpower.new=res.list$cpower
  d2.new=res.list$d2.new
  bound=res.list$bound
  return(list(n2.new=n2.new,cpower.new=cpower.new,d2.new=d2.new,bound=bound))
}


##################################################################
#################### Part 4: simulation code #####################
##################################################################


## the function is used to generate the survival time of the subjects in the control group
rweibull<-function(n,rate0,k)
  ## -n:number of observations. If length(n) > 1, the length is taken to be the number required
  ## -rate0:rates before the time of change
  ## -k:the weibull shape parameter
{
  U<-runif(n)
  radnm<-(-log(U))^(1/k)/rate0
  return(radnm)
}

## the function is used to generate the survival time of the subjects in the immunotherapy group
rpweibull<-function(rate0,lambda1,lambda2,tstar,k)
  ## -n:number of observations. If length(n) > 1, the length is taken to be the number required
  ## -rate0:rates before the time of change
  ## -rate1:rates after the time of change
  ## -tstar:the time of change
  ## -k:the weibull shape parameter
{
  Ustar<-exp(-lambda1*(rate0*tstar)^k)
  num=length(tstar)
  radnm=rep(NA,num)
  U<-runif(num)
  for(i in 1:num)
  {
    if(U[i]<Ustar[i])
    {
      radnm[i]<-((-log(U[i])+(lambda2-lambda1)*(rate0*tstar[i])^k)/lambda2)^(1/k)/rate0
    }
    else
    {
      radnm[i]<-(-log(U[i])/lambda1)^(1/k)/rate0
    }
  }
  return(radnm)
}

## produce the entry time points accroding to the Poisson process
rpoipross<-function(N,rate)
  ## -N:the number of time points
  ## -rate:intensity
{
  t=0
  S=rep(0,N)
  for(i in c(1:N))
  {
    U<-runif(1)
    t=t-log(U)/rate
    S[i]=t
  }
  return (S)
}

## This dataset is used to simulate the dataset used for the survival analysis
dataset.produce<-function(nc,nt,h.cens,A.start,A,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta,hypothesis)
  ## nc: the sample size of the patients recruited in the control group during the period of [A.start,A.start+A]
  ## nt: the sample size of the patients recruited in the control group during the period of [A.start,A.start+A]
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A.start: the calendar time point at which the recruitment of nc+nt subjects starts since the beginning of the clinical trial
  ## A: the duration of the recruitment
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
## hypothesis:0, the dataset is produced under the null hypothesis; 1, the dataset is produced under the alternative hypothesis
{
  datasetc<-matrix(ncol=7,nrow=nc)
  datasett<-matrix(ncol=7,nrow=nt)
  datasetc[,1]=rep(1,nc)## "1" represents the control group 
  datasett[,1]=rep(0,nt)## "0" represents the immunotherapy group 
  datasetc[,2]=rweibull(nc,rate0,k)## produce the survival time of the control group
  if(hypothesis==0&lambda1==lambda2)
  {
    datasett[,2]=rweibull(nt,rate0,k)## produce the survival time of the control group under the null hypothesis
  }
  else
  {
    tstar.vec=tstar.min+(tstar.max-tstar.min)*rbeta(nt,alpha,beta)## produce the individual delay time
    datasett[,2]=rpweibull(rate0,lambda1,lambda2,tstar.vec,k)
  }
  ##produce the entry time of control group and treatment group by poisson process
  entry=rpoipross(nc+nt,(nc+nt)/A)
  entry.total.order=c(1:(nc+nt))## original order number of two groups
  entry.control.order=sample(entry.total.order,nc)## select the order number corresponding to the entry time of the control group randomly
  entry.treatment.order=entry.total.order[-match(entry.control.order,entry.total.order)]## the rest is the order number of the treatment group
  entry.treatment.order=entry.treatment.order[sample(1:nt)]## permutate the order number of the treatment group
  ## Note: the recruitment time need to transformed the calendar time since the beginning of the clinical trial
  datasetc[,3]=A.start+entry[entry.control.order]## get the entry number of the control group
  datasett[,3]=A.start+entry[entry.treatment.order]## get the entry number of the treatment group
  ## produce the random censoring time
  datasetc[,4]=rexp(nc,h.cens)
  datasett[,4]=rexp(nt,h.cens)
  ## if the survial time is longer than the random censor time,the subject is censored (denoted by 0);uncersored vice versa (denoted by 1)
  datasetc[,5]=datasetc[,2]<datasetc[,4]
  datasett[,5]=datasett[,2]<datasett[,4]
  ## obtain the observation time since the recruitment of patients
  datasetc[,6]=apply(cbind(datasetc[,2],datasetc[,4]),1,min)
  datasett[,6]=apply(cbind(datasett[,2],datasett[,4]),1,min)
  ## obtain the observed time since the beginning of the clinical trial
  ## Note: the recruitment starts at the calendar time of A.start which has been added to the observation time in the recruitment time
  ## thus it does not required to be added in the observation time since the beginning of the clinical trial again!!!
  datasetc[,7]=datasetc[,6]+datasetc[,3]
  datasett[,7]=datasett[,6]+datasett[,3]
  dataset.cb0=rbind(datasett,datasetc)## combine two datasets
  dataset.cb=dataset.cb0[order(dataset.cb0[,7]),]## sort the matrix by the column,which represents "the end calendar time of actual visit"
  dataset.whole.1.0=matrix(nrow=nc+nt,ncol=8)## the whole dataset of the control arm and the treatment arm 
  dataset.whole.1.0[,1]=seq(1,nc+nt)## the order number of two groups
  dataset.whole.1.0[,2:8]=dataset.cb##the data need to store
  colnames(dataset.whole.1.0)=c("order.number","group","survival.time","entry.time","censorring.time","censor.or.death","actual.observed.time.since.recruitment","actual.observed.time.since.begining")
  return(dataset.whole.1.0)
}

## the prediction of the time of final analysis
final.analysis.time.predict<-function(n2.min,d2,n1,K,h.cens,A1,A2,tau.inf,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  ## n2.min: the initially planned sample size
  ## d2: the initially number of events
  ## n1: the number of the patients who are recruited by the end of the interim analysis
  ## K:the allocation ratio of the immunotherapy and control groups
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A1: the time of the interim analysis (a variable time; event-driven)
  ## A2: the duration of recruitment
  ## tau.inf: the minimum time of the interim or final analysis (corresponding to the largest hazard ratio and highest delay)
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
## tstar.min: the minimum possible delay time of an individual
## tstar.max: the maximum possible delay time of an individual
## alpha and beta: the shape parameters of the beta distribution
{
  root.function<-function(tau,n2.min,d2,n1,K,h.cens,A1,A2,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
  {
    d.true=death.number.updated(n1,n2.min,K,h.cens,A1,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta)
    diff=ceiling(d.true)-d2
    print(diff)
    return(diff)  
  }
  root=uniroot(root.function,n2.min=n2.min,d2=d2,n1=n1,K=K,h.cens=h.cens,A1=A1,A2=A2,rate0=rate0,k=k,lambda=lambda,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,lower=1/3*tau.inf,upper=3*tau.inf)$root
  return(root)
}

## the following function is used to estimate the model parameters using the MCMC approach
Parameters.reestimation.MCMC<-function(dataset.interim,tstar.min,tstar.max,num.adapt,num.burn,num.rep.tot,num.chain,num.thin)
  ## dataset.interim: the dataset obtained at the interim analysis, which is used to re-estimate the survival parameters
  ## tstar.min: the assumed minimum delay time 
  ## tstar.max: the assumed maximum delay time
  ## lambda.inf: the assumed minimum hazard ratio after the full onset of effect
  ## lambda.sub: the assumed maximum hazard ratio after the full onset of effect
  ## num.adapt: the number of iterations for adaptation
  ## num.burn: the number of the repetitions in the burn-in
  ## num.rep.tot: the number of repetitions in the sampling process
  ## num.chain: the number of Markov chains
  ## num.thin:thinning interval for monitors
{
  library(rjags)
  dataset.analysis=data.frame(dataset.interim)
  dataset.analysis$group=1-dataset.analysis$group
  X=model.matrix(~group,data=dataset.analysis)
  X <- X[, -1] # Remove intercept
  ## switch the labels of the groups: 
  ## 1 is used to represent the immunotherapy group
  ## 0 is used to represent the control group
  d.jags=list(n1=nrow(dataset.analysis),zeros=rep(0,nrow(dataset.analysis)),time=dataset.analysis$actual.observed.time.since.recruitment,X=X,delta=dataset.analysis$censor.or.death,tstar.min=tstar.min,tstar.max=tstar.max,logn=log(4))
  modelString="
  model
  {
    for(i in 1:n1)
    {
       ## Weibull baseline
       base[i]=k*h0k*pow(time[i],k-1)
       ## individual delay time
       y[i]~dbeta(a,b)T(0.001,0.999)
  		 tstar[i]<-tstar.min+y[i]*(tstar.max-tstar.min)
  		 ## hazard ratio
       elinpred[i]<-step(tstar[i]-time[i])+step(time[i]-tstar[i])*exp(beta*X[i])
       ## Log-Hazard function
       logHaz[i]<-log(base[i]*elinpred[i])
       ## Log-survival function
       logSurv[i]<--h0k*pow(time[i],k)*elinpred[i]+(elinpred[i]-1)*h0k*pow(tstar[i],k)
       phi[i]<-100000-delta[i]*logHaz[i]-logSurv[i]
       zeros[i]~dpois(phi[i])
    }
    a<-mu*eta
    b<-(1-mu)*eta
    mu~dbeta(1,1)
    eta<-exp(logeta)
    logeta~dlogis(logn,1)
    beta~dnorm(0,0.001)
    k~dunif(0,10)
    h0k~dgamma(0.01,0.01)
  	h0<-pow(h0k,1/k)
  }
  "
  writeLines( modelString , con="TEMPmodel.txt" )
  i.jags<-function()
  {
    mu<-runif(1,min=0.25,max=0.75)
    logeta<-rlogis(1,location=log(4),scale=1)
    beta=rnorm(1)
    k=runif(1,0.75,1.5)
    h0k=runif(1,0.025,0.1)
    y=runif(nrow(dataset.analysis),min=0.1,max=0.9)
    return(list(mu=mu,logeta=logeta,beta=beta,k=k,h0k=h0k,y=y))
  }
  p.jags=c("h0","k","beta","mu","logeta")
  adaptSteps=num.adapt        # Number of steps to adapt the samplers
  burnInSteps=num.burn           # Number of steps to burn-in the chains
  nChains=num.chain                  
  thinSteps=num.thin
  nIter=round(num.rep.tot/num.chain)
  ## the following codes may be wrong, thus the combination of try-catch is used to handle this issue
  ## Most of the errors happen in the initiation of the Markov chain
  MCMC.fun<-function(d.jags,i.jags,p.jags,nChains,adaptSteps,burnInSteps,nIter,thinSteps)
  {
    jagsModel=jags.model(file="TEMPmodel.txt",data=d.jags,inits=i.jags,n.chains=nChains,n.adapt=adaptSteps)
    # Burn-in:
    cat( "Burning in the MCMC chain...\n" )
    update(jagsModel,n.iter=burnInSteps)
    # The saved MCMC chain:
    cat( "Sampling final MCMC chain...\n" )
    codaSamples=coda.samples(jagsModel,variable.names=p.jags,n.iter=nIter,thin=thinSteps)
    return(codaSamples)
  }
  i=0
  repeat
  {
    i=i+1
    try.result=try(MCMC.fun(d.jags,i.jags,p.jags,nChains,adaptSteps,burnInSteps,nIter,thinSteps),silent=FALSE)
    if('try-error' %in% class(try.result))
    {
      next ## An error occur, repeat the conduction of the MCMC code
    }
    else
    {
      codaSamples=try.result
      break ## No error occur,break the repetation
    }
    if(i>5)
    {
      break
    }
  }
  result<-as.mcmc(do.call(rbind,codaSamples))
  h0.res<-result[,"h0"]
  h0<-mean(h0.res)
  k.res<-result[,"k"]
  k<-mean(k.res)
  beta.res<-result[,"beta"]
  beta=mean(beta.res)
  lambda=exp(beta)
  mu.res=result[,"mu"]
  mu=mean(mu.res)
  logeta.res=result[,"logeta"]
  logeta=mean(logeta.res)
  eta=exp(logeta)
  a<-mu*eta
  b<-(1-mu)*eta
  para.est<-list(a=a,b=b,k=k,h0=h0,lambda=lambda)
  return(para.est)
}

##implement the log-rank test
log.rank.test<-function(dataset.input)
  ## dataset.input is produced by the dataset.produce process
{
  dataset.analysis<-dataset.input[,c(2,7,6)]
  dataset.analysis<-dataset.analysis[order(dataset.analysis[,2]),]
  dataset.cum<-NA
  record.begin=0
  num.tot<-length(dataset.analysis[,1])
  num.itr<-num.tot
  num.trt<-sum(dataset.analysis[,1]==0)#0 stands for the immunotherapy group
  num.ctr<-sum(dataset.analysis[,1]==1)#1 stands for the control group
  for(i in 1:num.tot)
  {
    if(i==1||dataset.analysis[i,2]!=dataset.analysis[i-1,2])
    {
      death.vector<-c(0,0,0)
      if(dataset.analysis[i,3]==1)
      {
        if(dataset.analysis[i,1]==1)##1 stands for the control group
        {
          death.vector[1]=1
        }
        else if(dataset.analysis[i,1]==0)##0 stands for the immunotherapy group
        {
          death.vector[2]=1
        }
        death.vector[3]=1
      }
      itr.ele=c(dataset.analysis[i,2],num.ctr,num.trt,num.itr,death.vector)
    }
    else if(dataset.analysis[i,2]==dataset.analysis[i-1,2])
    {
      death.vector.add<-c(0,0,0)
      if(dataset.analysis[i,3]==1)
      {
        if(dataset.analysis[i,1]==1)
        {
          death.vector.add[1]=1
        }
        else if(dataset.analysis[i,1]==0)
        {
          death.vector.add[2]=1
        }
        death.vector.add[3]=1
      }
      death.vector=death.vector+death.vector.add
      itr.ele=c(dataset.analysis[i,2],num.ctr,num.trt,num.itr,death.vector)
    }
    if(record.begin==0)
    {
      if(dataset.analysis[i,3]==1&dataset.analysis[i,2]!=dataset.analysis[i+1,2])
      {
        dataset.cum=itr.ele
        record.begin=1
      }
    }
    else if(i<num.tot)
    {
      if(dataset.analysis[i,3]==1&dataset.analysis[i,2]!=dataset.analysis[i+1,2])
      {
        dataset.cum=rbind(dataset.cum,itr.ele)
      }
    }
    else if(dataset.analysis[i,3]==1&i==num.tot)
    {
      dataset.cum=rbind(dataset.cum,itr.ele)
    }
    num.itr=num.itr-1
    if(dataset.analysis[i,1]==1)
    {
      num.ctr=num.ctr-1
    }
    else
    {
      num.trt=num.trt-1
    }
  }
  colnames(dataset.cum)<-c("Survival.time","num.ctr","num.trt","num.tot","death.ctr","death.trt","death.tot")
  num.dist<-length(dataset.cum[,1])
  Sw=matrix(0,nrow=num.dist,ncol=3)
  for(i in 1:(num.dist-1))
  {
    Sw[i,1]=i
    d1j=dataset.cum[i,5]
    dj=dataset.cum[i,7]
    n1j=dataset.cum[i,2]
    n2j=dataset.cum[i,3]
    nj=n1j+n2j
    e1j=n1j*dj/nj
    nume.add=d1j-e1j
    denume.add=n1j*n2j*dj*(nj-dj)/nj^2/(nj-1)
    if(i!=1)
    {
      Sw[i,2]=Sw[i-1,2]+nume.add
      Sw[i,3]=Sw[i-1,3]+denume.add
    }
    else
    {
      Sw[i,2]=nume.add
      Sw[i,3]=denume.add
    }
  }
  Sw[num.dist,1]=num.dist
  d1j=dataset.cum[num.dist,5]
  dj=dataset.cum[num.dist,7]
  n1j=dataset.cum[num.dist,2]
  n2j=dataset.cum[num.dist,3]
  nj=n1j+n2j
  e1j=n1j*dj/nj
  nume.add=d1j-e1j
  denume.add=n1j*n2j*dj/nj^2
  Sw[num.dist,2]=Sw[num.dist-1,2]+nume.add
  Sw[num.dist,3]=Sw[num.dist-1,3]+denume.add
  ##get the value of the log-rank statistics corresponding to interim analysis and final analysis
  Sw_used=Sw[num.dist,]
  z1<-Sw_used[2]/sqrt(Sw_used[3])## calculate the standardized value of the piecewise weitghted log-rank test statistics
  t1<-Sw_used[2]## calculate the standardized value of the piecewise weighted log-rank test
  return(list(z1=z1,t1=t1))
}

library(parallel)

adaptive.design.one.run.simulation<-function(order,significance,K,n2.min,n2.max,d1,d2,h.cens,A2,tau,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta,power,hypothesis,num.adapt,num.burn,num.rep.tot,num.chain,num.thin)
  ## order: the order number of simulated adpative trial
  ## significance: the significance level
  ## K:the allocation ratio of the immunotherapy and control groups
  ## n2.min: the initial specification at the final analysis
  ## n2.max: the maximum possible sample size at the final analysis
  ## d1:the number of the events by the end of the interim analysis
  ## d2:the initial assumed number of the events by the end of the final analysis
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A2: the time of the end of the recruitment
  ## tau:the calendar time of the analysis
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## alpha and beta are the actual values
  ## power: the nominal power
  ## hypothesis??0, the null hypothesis; 1, the alternative hypothesis.
  ## num.adapt: the number of iterations for adaptation
  ## num.burn: the number of the repetitions in the burn-in
  ## num.rep.tot: the number of repetitons in the sampling process
  ## num.chain: the number of Markov chains
  ## num.thin:thinning interval for monitors
{
  adaptive.design.try<-function()
  {
    S=Sys.time()
    Event.num=d2
    Sample.size=n2.min
    n2c.min=round(n2.min/(K+1))
    n2t.min=n2.min-n2c.min
    dataset.interim<-dataset.produce(n2c.min,n2t.min,h.cens,A.start=0,A=A2,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta,hypothesis)
    death.cum.vec<-cumsum(dataset.interim[,6])
    order.num=sum(death.cum.vec<d1)+1
    analysis.time=as.numeric(dataset.interim[order.num,8])## The calendar time of the interim analysis is event-driven by d1;
    Interim.time=analysis.time
    dataset.interim<-dataset.interim[dataset.interim[,4]<=analysis.time,]
    n1=nrow(dataset.interim)## the sample size recruited at the interim analysis is event-driven
    dataset.interim.copy=dataset.interim## No administrative censoring; the dataset is copied for the final analysis
    dataset.interim[dataset.interim[,8]>analysis.time,6]=0
    dataset.interim[dataset.interim[,8]>analysis.time,7]=analysis.time-dataset.interim[dataset.interim[,8]>analysis.time,4]
    dataset.interim[dataset.interim[,8]>analysis.time,8]=analysis.time
    Interim.analysis=log.rank.test(dataset.interim)
    z1=Interim.analysis$z1
    ##  dataset.interim is used to estimate the parameters because the administratively censored observations required to be taken into consideration
    Para.est<-Parameters.reestimation.MCMC(dataset.interim,tstar.min,tstar.max,num.adapt,num.burn,num.rep.tot,num.chain,num.thin)
    alpha.est=Para.est$a
    beta.est=Para.est$b
    k.est=Para.est$k
    rate0.est=Para.est$h0
    lambda.est=Para.est$lambda
    ## the final analysis is event-driven; thus, the calendar time requires to be adjusted when the survival parameters are changed  
    tau.pre<-final.analysis.time.predict(n2.min,d2,n1,K,h.cens,A1=Interim.time,A2,tau.inf=tau,rate0=rate0.est,k=k.est,lambda=lambda.est,tstar.min,tstar.max,alpha=alpha.est,beta=beta.est)
    Cpower.min.list=Conditional.power.adaptive.design(n1,n2.min,significance,z1,d1,d2,K,h.cens,A1=Interim.time,A2,tau.pre,rate0=rate0.est,k=k.est,lambda=lambda.est,tstar.min,tstar.max,alpha=alpha.est,beta=beta.est)
    Cpower.min=Cpower.min.list$cpower
    Cpower.max.list=Conditional.power.adaptive.design(n1,n2.max,significance,z1,d1,d2,K,h.cens,A1=Interim.time,A2,tau.pre,rate0=rate0.est,k=k.est,lambda=lambda.est,tstar.min,tstar.max,alpha=alpha.est,beta=beta.est)
    Cpower.max=Cpower.max.list$cpower
    if(Cpower.min<power&Cpower.max>=power)
    {
      ## The result is promising when the minimum conditional power is less than the nominal power and the maximum conditional power is larger than the nominal power
      re.est.list<-n2.reestimation.adpative.design(n1,n2.min,n2.max,significance,z1,d1,d2,K,h.cens,A1=Interim.time,A2,tau=tau.pre,rate0=rate0.est,k=k.est,lambda=lambda.est,tstar.min,tstar.max,alpha=alpha.est,beta=beta.est,power)
      Sample.size=re.est.list$n2.new
      Critical.value=as.numeric(re.est.list$bound)
      Event.num=re.est.list$d2.new
    }
    else
    {
      Critical.value=as.numeric(Cpower.min.list$bound)
      Event.num=Cpower.min.list$d2.new
    }
    n.extra=Sample.size-n1
    nc.extra=round(n.extra/(K+1))
    nt.extra=n.extra-nc.extra
    dataset.extra<-dataset.produce(nc.extra,nt.extra,h.cens,A.start=Interim.time,A=A2-Interim.time,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta,hypothesis)
    dataset.whole=rbind(dataset.interim.copy,dataset.extra)
    unordered.observation.time=dataset.whole[,8]
    order.vector=order(unordered.observation.time)
    dataset.whole=dataset.whole[order.vector,]## The combined dataset need to be reordered by the observation time since the beginning of the clinical trial
    death.cum.vec<-cumsum(dataset.whole[,6])
    order.num=sum(death.cum.vec<Event.num)+1
    analysis.time=as.numeric(dataset.whole[order.num,8])## The calendar time of the interim analysis is event-driven by d1;
    Final.time=analysis.time
    dataset.analysis<-dataset.whole[dataset.whole[,4]<=analysis.time,]
    dataset.analysis[dataset.analysis[,8]>analysis.time,6]=0
    dataset.analysis[dataset.analysis[,8]>analysis.time,7]=analysis.time-dataset.analysis[dataset.analysis[,8]>analysis.time,4]
    dataset.analysis[dataset.analysis[,8]>analysis.time,8]=analysis.time
    Final.analysis=log.rank.test(dataset.analysis)
    z2=Final.analysis$z1
    Decision=ifelse(z2>=Critical.value,1,0)
    E=Sys.time()
    print(E-S)
    return(c(order=order,test.statistics.1=z1,test.statistics.2=z2,Critical.value=Critical.value,Decision=Decision,Event.num=Event.num,Sample.size=Sample.size,Interim.time=Interim.time,Final.time=Final.time,alpha.est=alpha.est,beta.est=beta.est,k.est=k.est,rate0.est=rate0.est,lambda.est=lambda.est,Cpower.min=Cpower.min,Cpower.max=Cpower.max,Interim.sample.size=n1))
  }
  i=0
  repeat
  {
    i=i+1
    try.result=try(adaptive.design.try(),silent=FALSE)
    if('try-error' %in% class(try.result))
    {
      next ## An error occur, repeat the conduction of the MCMC code
    }
    else
    {
      result=try.result
      break ## No error occur,break the repetation
    }
    if(i>5)
    {
      break
    }
  }
  return(result)
}

adaptive.design.simulation<-function(significance,K,n2.min,n2.max,d1,d2,h.cens,A2,tau,rate0,k,lambda1,lambda2,tstar.min,tstar.max,alpha,beta,simnum,power,hypothesis,num.adapt,num.burn,num.rep.tot,num.chain,num.thin)
  ## significance: the significance level
  ## K:the allocation ratio of the immunotherapy and control groups
  ## n2.min: the minimum sample size
  ## n2.max: the maximum sample size
  ## d1:the number of the events by the end of the interim analysis
  ## d2:the initial assumed number of the events by the end of the final analysis
  ## h.cens:the random censoring hazard (assuming the random censoring time follows the exponential distribution)
  ## A2: the time of the end of the recruitment
  ## tau:the calendar time of the analysis
  ## rate0: the hazard parameter of the control group
  ## k:the shape parameter
  ## lambda: the hazard ratio of the immunotherapy and control groups after the delayed onset of effect
  ## the delay time is assumed to follow the distribution tstar~tstar.min+(tstar.max-tstar.min)*x, x~Beta(alpha,beta)
  ## tstar.min: the minimum possible delay time of an individual
  ## tstar.max: the maximum possible delay time of an individual
  ## alpha and beta are the actual values
  ## Unfavorable zone: Cpower.max<power
  ## promising zone: CPower.max>=power and CPower.min<power;
  ## Favorable zone: CPower.min>=power
  ## simnum: the number of the repetitions
  ## power: the nominal power
  ## hypothesis:0, the null hypothesis; 1, the alternative hypothesis
  ## num.adapt: the number of iterations for adaptation
  ## num.burn: the number of the repetitions in the burn-in
  ## num.rep.tot: the number of repetitons in the sampling process
  ## num.chain: the number of Markov chains
  ## num.thin:thinning interval for monitors
{
  varlist=c("rweibull","rpweibull","rpoipross","rpoipross","dataset.produce","log.rank.test","n2.reestimation.adpative.design","Conditional.power.adaptive.design","death.number.updated","bound.determination.in.adaptive.design","Dist.para.fixed.design","Dist.para.adaptive.design","surv.control","surv.immuno","surv.immuno.ind","hazard.control","hazard.immuno","pdf.immuno","Surv.adm.censor","Parameters.reestimation.MCMC","final.analysis.time.predict","Death.number.expected")
  S<-Sys.time()
  library(parallel)
  core.num=max(detectCores(logical=FALSE)-4,4)
  cl<-makeCluster(getOption("cl.cores",core.num))
  clusterExport(cl,varlist=varlist,envir=environment())
  Simul.res.list<-parLapplyLB(cl,seq(1,simnum,1),adaptive.design.one.run.simulation,significance=significance,K=K,n2.min=n2.min,n2.max=n2.max,d1=d1,d2=d2,h.cens=h.cens,A2=A2,tau=tau,rate0=rate0,k=k,lambda1=lambda1,lambda2=lambda2,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,power=power,hypothesis=hypothesis,num.adapt=num.adapt,num.burn=num.burn,num.rep.tot=num.rep.tot,num.chain=num.chain,num.thin=num.thin)
  stopCluster(cl)
  Simul.res <- do.call(rbind,Simul.res.list)
  ## The columns of the matrix Simul.res are in turn as follows, respecitvely
  ## order: the order number of the simulation trial
  ## test.statistics 1: the value of the log-rank test statistics at the interim analysis
  ## test.statistics 2: the value of the log-rank test statistics at the final analysis
  ## Critical.value: Critical value at the final analysis
  ## Decision: 1 standards for the fact that the null hypothesis is rejected at the final analysis; otherwise, 0 stands for the fact that the null hypothesis is not rejected at the final analysis.
  ## Event.num: the actual number of the observations of the events of interest by the end of the final analysis
  ## Sample.size: the sample size at the final analysis
  ## Interim.time: the calendar time of the interim analysis
  ## Final.time: the caldendar time of the final analysis
  ## alpha.est: the estimation of the shape parameter alpha of the delay time
  ## beta.est: the estimation of the shape parameter beta of the delay time
  ## k.est: the estimation of the shape parameter k of the survival function of the control group
  ## rate0.est: the estimation of the hazard parameter h0 of the survival function of the control group
  ## lambda.est: the estimation of the hazard ratio after the delay time
  ## Cpower.min: the conditional power for the initial sample size
  ## Cpower.max: the conditional power for the maximum sample size
  test.statistics.matrix=Simul.res[,c(2,3)]
  Critical.value=Simul.res[,4]
  Decision.simulation=Simul.res[,5]
  Event.num.actual=Simul.res[,6]
  Sample.size.actual=Simul.res[,7]
  Interim.time=Simul.res[,8]
  Final.time=Simul.res[,9]
  Para.est=Simul.res[,seq(10,14,1)]
  Cpower.min=Simul.res[,15]
  Cpower.max=Simul.res[,16]
  Power=mean(Decision.simulation)
  Test.and.decision=data.frame(cbind(test.statistics.matrix,Cpower.min,Cpower.max,Decision.simulation))
  colnames(Test.and.decision)=c("Interim","Final","Cpower.min","Cpower.max","Decision.simulation")
  ## Unfavorable results
  Test.and.decision.unfavorable=Test.and.decision[Test.and.decision$Cpower.max<power,]
  Power.unfavorable=mean(Test.and.decision.unfavorable$Decision.simulation)
  Prop.unfavorable=length(Test.and.decision.unfavorable$Decision.simulation)/simnum
  ## Promising results
  Test.and.decision.promising=Test.and.decision[Test.and.decision$Cpower.max>=power&Test.and.decision$Cpower.min<power,]
  Power.promising=mean(Test.and.decision.promising$Decision.simulation)
  Prop.promising=length(Test.and.decision.promising$Decision.simulation)/simnum
  Conditional.power.min.promising=min(Test.and.decision.promising$Cpower.min)
  Conditional.power.max.promising=max(Test.and.decision.promising$Cpower.min)
  z1.sup.empirical=max(Test.and.decision.promising$Interim)
  z1.inf.empirical=min(Test.and.decision.promising$Interim)
  ## Favorable results
  Test.and.decision.favorable=Test.and.decision[Test.and.decision$Cpower.min>=power,]
  Power.favorable=mean(Test.and.decision.favorable$Decision.simulation)
  Prop.favorable=length(Test.and.decision.favorable$Decision.simulation)/simnum
  Mean.event.num=mean(Event.num.actual)
  Mean.sample.size=mean(Sample.size.actual)
  Parameter.list<-list(significance=significance,K=K,n2.min=n2.min,n2.max=n2.max,d1=d1,d2=d2,h.cens=h.cens,A2=A2,tau=tau,rate0=rate0,k=k,lambda1=lambda1,lambda2=lambda2,tstar.min=tstar.min,tstar.max=tstar.max,alpha=alpha,beta=beta,simnum=simnum,power=power,hypothesis=hypothesis,num.adapt=num.adapt,num.burn=num.burn,num.rep.tot=num.rep.tot,num.chain=num.chain,num.thin=num.thin)
  Power.list=list(Power=Power,Power.unfavorable=Power.unfavorable,Power.promising=Power.promising,Power.favorable=Power.favorable,Conditional.power.min.promising=Conditional.power.min.promising,Conditional.power.max.promising=Conditional.power.max.promising,z1.inf.empirical=z1.inf.empirical,z1.sup.empirical=z1.sup.empirical)
  Prop.zone.list=list(Prop.unfavorable=Prop.unfavorable,Prop.promising=Prop.promising,Prop.favorable=Prop.favorable)
  E<-Sys.time()
  print(E-S)
  Total.time=E-S
  return(list(Mean.sample.size=Mean.sample.size,Mean.event.num=Mean.event.num,Parameter.list=Parameter.list,Power.list=Power.list,Prop.zone.list=Prop.zone.list,Original.data=Simul.res,Total.time=Total.time))
}