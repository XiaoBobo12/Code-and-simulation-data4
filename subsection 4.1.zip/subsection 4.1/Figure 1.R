setwd("D:/研究备份/研究5（针对随机延迟效应的免疫治疗的贝叶斯自适应设计）/绘图制表代码")
load("Scenario_1_to_9.RData")
load("Scenario_1_to_9_2.RData")
results.pres<-data.frame(matrix(ncol=8,nrow=144))
varnames<-c("a.b","lambda","x.cat","Overall","Unfavorable","Promising","Favorable","Design")
colnames(results.pres)<-varnames
for(i in 1:72)
{
  a=AD.simul.list[[i]]$Parameter.list$alpha
  b=AD.simul.list[[i]]$Parameter.list$beta
  results.pres$a.b[i]=paste("(list(a,b))==(list(",a,",",b,"))")
  results.pres$lambda[i]=AD.simul.list[[i]]$Parameter.list$lambda
  d1=AD.simul.list[[i]]$Parameter.list$d1
  d20=AD.simul.list[[i]]$Parameter.list$d2
  n20=AD.simul.list[[i]]$Parameter.list$n2.min
  n2max=AD.simul.list[[i]]$Parameter.list$n2.max
  results.pres$x.cat[i]=paste(d1,d20,n20,n2max,sep="\n")
  results.pres$Overall[i]=AD.simul.list[[i]]$Power.list$Power
  results.pres$Unfavorable[i]=AD.simul.list[[i]]$Power.list$Power.unfavorable
  results.pres$Promising[i]=AD.simul.list[[i]]$Power.list$Power.promising
  results.pres$Favorable[i]=AD.simul.list[[i]]$Power.list$Power.favorable
  results.pres$Design[i]="Promising zone design"
}
for(i in 1:72)
{
  a=FD.simul.list[[i]]$Parameter.list$alpha
  b=FD.simul.list[[i]]$Parameter.list$beta
  results.pres$a.b[i+72]=paste("(list(a,b))==(list(",a,",",b,"))")
  results.pres$lambda[i+72]=FD.simul.list[[i]]$Parameter.list$lambda
  d1=FD.simul.list[[i]]$Parameter.list$d1
  d20=FD.simul.list[[i]]$Parameter.list$d2
  n20=FD.simul.list[[i]]$Parameter.list$n2.min
  n2max=FD.simul.list[[i]]$Parameter.list$n2.max
  results.pres$x.cat[i+72]=paste(d1,d20,n20,n2max,sep="\n")
  results.pres$Overall[i+72]=FD.simul.list[[i]]$Power.list$Power
  results.pres$Unfavorable[i+72]=FD.simul.list[[i]]$Power.list$Power.unfavorable
  results.pres$Promising[i+72]=FD.simul.list[[i]]$Power.list$Power.promising
  results.pres$Favorable[i+72]=FD.simul.list[[i]]$Power.list$Power.favorable
  results.pres$Design[i+72]="Fixed sample design"
}
library(reshape2)
results.pres$lambda=paste("italic(lambda) ==",results.pres$lambda,sep="")
results.pres.long=melt(results.pres,id.vars = c("a.b","lambda","x.cat","Design"),variable.name="Power.type",value.name = "Power.value")
results.pres.long$a.b=factor(results.pres.long$a.b)
results.pres.long$lambda=factor(results.pres.long$lambda)
results.pres.long$x.cat=factor(results.pres$x.cat)
results.pres.long$x.cat.num=rep(NA,576)
levels.x.cat=levels(results.pres.long$x.cat)
results.pres.long$Design=factor(results.pres.long$Design,levels=c("Promising zone design","Fixed sample design"),labels=c("Promising zone design","Fixed sample design"))
for(i in 1:8)
{
  results.pres.long$x.cat.num[results.pres.long$x.cat==levels.x.cat[i]]=i
}
library(ggplot2)
dev.set()
bitmap("D:/BoshengLi_Figure1.jpeg",type="jpeg",height =10.5 ,width = 18,res=800)
p<-ggplot(data=results.pres.long,mapping = aes(x=x.cat.num,y=Power.value,color=Power.type,shape=Power.type,linetype=Design))+geom_line(linewidth=1)+geom_point(size=3)
p<-p+facet_grid(a.b~lambda,labeller = label_parsed)+scale_x_continuous(breaks=seq(1,8,1),labels=levels.x.cat)+xlab((bquote((list(d[1],d[2]^0,n[2]^0,n[2]^max)))))+ylab("Empirical power")
p<-p+scale_color_discrete(name="Type of power")+scale_shape_discrete(name="Type of power")+theme(axis.title = element_text(size=14),axis.text = element_text(size=12),legend.text = element_text(size=12),legend.title=element_text(size=14),strip.text = element_text(size=12))
p
dev.off()