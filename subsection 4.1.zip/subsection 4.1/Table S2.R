setwd("D:/研究备份/研究5（针对随机延迟效应的免疫治疗的贝叶斯自适应设计）/绘图制表代码")
load("Scenario_1_to_9.RData")
load("Scenario_1_to_9_2.RData")
results.pres<-data.frame(matrix(ncol=14,nrow=72))
colnames(results.pres)<-c("a.b","lambda","d1","d20","n20","n2max","FD.PROP.UF","FD.PROP.PR","FD.PROP.FA","AD.PROP.UF","AD.PROP.PR","AD.PROP.FA","AD.ED","AD.EN")
for(i in 1:72)
{
  a=AD.simul.list[[i]]$Parameter.list$alpha
  b=AD.simul.list[[i]]$Parameter.list$beta
  results.pres$a.b[i]=paste("(",a,",",b,")",sep="")
  results.pres$lambda[i]=AD.simul.list[[i]]$Parameter.list$lambda
  results.pres$d1[i]=AD.simul.list[[i]]$Parameter.list$d1
  results.pres$d20[i]=AD.simul.list[[i]]$Parameter.list$d2
  results.pres$n20[i]=AD.simul.list[[i]]$Parameter.list$n2.min
  results.pres$n2max[i]=AD.simul.list[[i]]$Parameter.list$n2.max
  results.pres$FD.PROP.UF[i]=FD.simul.list[[i]]$Prop.zone.list$Prop.unfavorable
  results.pres$FD.PROP.PR[i]=FD.simul.list[[i]]$Prop.zone.list$Prop.promising
  results.pres$FD.PROP.FA[i]=FD.simul.list[[i]]$Prop.zone.list$Prop.favorable
  results.pres$AD.PROP.UF[i]=AD.simul.list[[i]]$Prop.zone.list$Prop.unfavorable
  results.pres$AD.PROP.PR[i]=AD.simul.list[[i]]$Prop.zone.list$Prop.promising
  results.pres$AD.PROP.FA[i]=AD.simul.list[[i]]$Prop.zone.list$Prop.favorable
  results.pres$AD.ED[i]=AD.simul.list[[i]]$Mean.event.num
  results.pres$AD.EN[i]=AD.simul.list[[i]]$Mean.sample.size
}
write.csv(x=results.pres,file="Table S2.csv")
