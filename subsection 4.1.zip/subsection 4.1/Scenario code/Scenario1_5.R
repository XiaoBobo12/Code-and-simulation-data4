rm(list=ls())
setwd("/home/user1/LBS")
source("Bayesian.adaptive.design.JAGS.R")
significance=0.025
power=0.9
K=1
tau=96
A2=48
A1=36
h.cens=-log(0.99)/12
rate0=0.075
k=1.3
tstar.max=6
tstar.min=1
lambda.min=0.6
list.min=n2min.determination.adaptive.design(significance,power,K,h.cens,A1,A2,tau,rate0,k,lambda.min,tstar.min)
n2.min<-list.min$n2.min
n1<-list.min$n1
d1<-list.min$d1
d2<-list.min$d2
n2.max=2*n2.min
simnum=10000
num.adapt=5000
num.burn=5000
num.rep.tot=300000
num.chain=3
num.thin=100
hypothesis=1
# variable paramteters
lambda=0.65
alpha=1
beta=3
# Begin the simulation
# the results are saved in the lists AD.simul and FD.simul
AD.simul<-adaptive.design.simulation(significance,K,n2.min,n2.max,d1,d2,h.cens,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,simnum,power,hypothesis,num.adapt,num.burn,num.rep.tot,num.chain,num.thin)
save.image("Scenario1_5.RData")
FD.simul<-fixed.sample.simulation(significance,K,n2.min,n2.max,d1,d2,h.cens,A2,tau,rate0,k,lambda,tstar.min,tstar.max,alpha,beta,simnum,hypothesis,num.adapt,num.burn,num.rep.tot,num.chain,num.thin)
save.image("Scenario1_5.RData")  
