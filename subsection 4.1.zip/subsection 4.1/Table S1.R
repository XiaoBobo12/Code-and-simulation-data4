setwd("D:/研究备份/研究5（针对随机延迟效应的免疫治疗的贝叶斯自适应设计）/绘图制表代码")
load("Scenario_1_to_9.RData")
load("Scenario_1_to_9_2.RData")
results.pres<-data.frame(matrix(ncol=14,nrow=72))
colnames(results.pres)<-c("a.b","lambda","d1","d20","n20","n2max","FD.EP","FD.EP.UF","FD.EP.PR","FD.EP.FA","AD.EP","AD.EP.UF","AD.EP.PR","AD.EP.FA")
for(i in 1:72)
{
  a=AD.simul.list[[i]]$Parameter.list$alpha
  b=AD.simul.list[[i]]$Parameter.list$beta
  results.pres$a.b[i]=paste("(",a,",",b,")",sep="")
  results.pres$lambda[i]=AD.simul.list[[i]]$Parameter.list$lambda
  results.pres$d1[i]=AD.simul.list[[i]]$Parameter.list$d1
  results.pres$d20[i]=AD.simul.list[[i]]$Parameter.list$d2
  results.pres$n20[i]=AD.simul.list[[i]]$Parameter.list$n2.min
  results.pres$n2max[i]=AD.simul.list[[i]]$Parameter.list$n2.max
  results.pres$FD.EP[i]=FD.simul.list[[i]]$Power.list$Power
  results.pres$FD.EP.UF[i]=FD.simul.list[[i]]$Power.list$Power.unfavorable
  results.pres$FD.EP.PR[i]=FD.simul.list[[i]]$Power.list$Power.promising
  results.pres$FD.EP.FA[i]=FD.simul.list[[i]]$Power.list$Power.favorable
  results.pres$AD.EP[i]=AD.simul.list[[i]]$Power.list$Power
  results.pres$AD.EP.UF[i]=AD.simul.list[[i]]$Power.list$Power.unfavorable
  results.pres$AD.EP.PR[i]=AD.simul.list[[i]]$Power.list$Power.promising
  results.pres$AD.EP.FA[i]=AD.simul.list[[i]]$Power.list$Power.favorable
}
write.csv(x=results.pres,file="Table S1.csv")